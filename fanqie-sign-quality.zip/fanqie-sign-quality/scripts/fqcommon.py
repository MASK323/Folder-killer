# -*- coding: utf-8 -*-
"""fanqie-sign-quality 共用文本工具（纯标准库，任意题材通用）。

设计原则：不预设人物名、不预设题材词表。凡"高频/模板"类指标一律从文本自身统计得出。
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

# ---------- 文本规范化 ----------

# 去标点口径：只保留 Unicode 词字符（汉字/字母/数字），其余全部剔除。
# 说明：平台判重是"去掉标点与空白后完全相同"，标点差异不影响判定，故这里与平台口径一致。
_NON_WORD = re.compile(r"[\W_]+", re.UNICODE)
TEXT_EXT = {".txt", ".md"}

DIALOG_MARKS = ("“", "”", "「", "」", "『", "』", '"')


def norm(s: str) -> str:
    """去标点与空白，用于判重比较（与平台口径一致：标点差异不影响判定）。"""
    return _NON_WORD.sub("", s)


def is_dialogue(line: str) -> bool:
    return any(m in line for m in DIALOG_MARKS)


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"[。！？…\n]+", text)
    return [p.strip() for p in parts if len(p.strip()) >= 2]


def ngrams(text: str, n: int) -> list[str]:
    if len(text) < n:
        return []
    return [text[i : i + n] for i in range(len(text) - n + 1)]


def set_ngrams(text: str, n: int) -> set[str]:
    return set(ngrams(text, n))


def jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def cv(values: list[float]) -> float:
    """变异系数：标准差/均值。越低越"均匀"（机器生成特征）。"""
    xs = [v for v in values if v is not None]
    if len(xs) < 2:
        return 0.0
    m = sum(xs) / len(xs)
    if m == 0:
        return 0.0
    var = sum((x - m) ** 2 for x in xs) / len(xs)
    return (var**0.5) / m


# ---------- 章节发现 ----------

CHAP_RE = re.compile(r"第\s*([0-9零一二三四五六七八九十百千万两]+)\s*[章节回集卷]")
_CN_NUM = {c: i for i, c in enumerate("零一二三四五六七八九", start=0)}


def _cn2int(s: str) -> int | None:
    if s.isdigit():
        return int(s)
    if all(c in _CN_NUM for c in s):
        return int("".join(str(_CN_NUM[c]) for c in s))
    return None


@dataclass
class Chapter:
    no: int
    title: str
    path: Path
    text: str
    lines: list[str] = field(default_factory=list)

    @property
    def body_norm(self) -> str:
        return norm(self.text)

    @property
    def chars(self) -> int:
        return len(self.body_norm)


# 这些目录/文件是脚本自己的产出或缓存，绝不能被当成章节读进来
_SKIP_DIR_MARKS = ("签约优化", "签约评估", "签约审计", ".dup_backup", "logs", "_report")
_SKIP_FILE_PREFIX = ("sign_", "sign_fix", "sign_quality")
_EXTRA_SKIP_FILE_NAMES = {"readme.md", "说明.md"}


def _skip_dir(name: str) -> bool:
    return name.startswith(".") or name.startswith("_") or any(m in name for m in _SKIP_DIR_MARKS)


def _skip_file(name: str) -> bool:
    low = name.lower()
    return low.startswith(_SKIP_FILE_PREFIX) or low in _EXTRA_SKIP_FILE_NAMES


def discover_chapters(root: Path) -> list[Chapter]:
    """递归发现章节；文件名含「第N章」时按其排序，否则按路径自然序。"""
    root = Path(root)
    files: list[Path] = []
    if root.is_file():
        files = [root]
    else:
        for p in sorted(root.rglob("*")):
            if not p.is_file() or p.suffix.lower() not in TEXT_EXT:
                continue
            if _skip_file(p.name) or any(_skip_dir(part) for part in p.relative_to(root).parts[:-1]):
                continue
            files.append(p)
    out: list[Chapter] = []
    for i, p in enumerate(files):
        text = p.read_text(encoding="utf-8", errors="ignore")
        m = CHAP_RE.match(p.stem)
        no = _cn2int(m.group(1)) if m else None
        out.append(
            Chapter(
                no=no if no is not None else 10_000 + i,
                title=p.stem,
                path=p,
                text=text,
                lines=[ln.strip() for ln in text.splitlines() if ln.strip()],
            )
        )
    out.sort(key=lambda c: (c.no, str(c.path)))
    return out


# ---------- 内容安全扫描（报告用，绝不自动改） ----------

SAFETY_PATTERNS: dict[str, str] = {
    # 高精度优先：宁可少报，也不要让作者对着一堆误报做无用功。
    "色情低俗": r"做爱|性交|口交|肛交|裸体|下体|阴部|阴茎|阴道|乳房|高潮|呻吟|卖淫|嫖娼|援交|色情|淫水|淫叫|肉欲|上床(?!谈)|脱光",
    "未成年负向": r"幼女|幼童|萝莉|未成年(?:人)?[^。]{0,6}(?:性|裸|孕|怀孕)|早恋|校园霸凌|跳楼自杀",
    "暴力引人不适": r"开膛|剖腹|肢解|碎尸|剥皮|虐杀|凌迟|挖眼|斩首|血肉模糊|肠子(?:流|拖)|斩断头颅",
    "违背伦理": r"乱伦|恋尸|兽交|人兽交|性虐待|奸尸",
    "时政民族宗教": r"邪教|法轮功|台独|藏独|疆独|民族仇恨|宗教极端|恐怖袭击|颠覆国家",
    "赌博毒品": r"吸毒|冰毒|海洛因|可卡因|摇头丸|大麻(?!烦)|赌场|赌资|开赌|聚众赌博",
    "封建迷信渲染": r"包治百病|驱邪治病|通灵治病|改命转运|活人献祭",
}
_SAFETY_RE = {k: re.compile(v) for k, v in SAFETY_PATTERNS.items()}

_TRAD_ONLY = set(
    "們個這裡說時後過來對發現學會開關見東車長門問間實際樣種現場點兒氣風讀寫書國語話錢銀鐵劍靈體藥聲頭臉腳誰麼為與並況處匯確權歲豐寶號亂靜聽覺觀戰歸還親愛東漢語驚訝騙"
)

# 允许出现的"非汉字"字符码位区间（凡不在这些区间、又不在汉字区的，才算异常字符）
_ALLOWED_RANGES = (
    (0x0020, 0x007E),  # ASCII 可打印
    (0x00A0, 0x00BF),  # 拉丁补充（·等）
    (0x2010, 0x2027),  # 引号/破折号/省略号
    (0x2030, 0x205E),
    (0x3000, 0x303F),  # 中日韩标点
    (0x4E00, 0x9FFF),  # 汉字
    (0xFE30, 0xFE4F),  # 兼容形式
    (0xFF00, 0xFFEF),  # 全角字符（，！？等全在这里）
)


def _is_allowed_char(c: str) -> bool:
    o = ord(c)
    if c in "\n\t\r\u3000\uFEFF":
        return True
    return any(lo <= o <= hi for lo, hi in _ALLOWED_RANGES)


def scan_safety(ch: Chapter) -> list[dict]:
    hits = []
    for i, ln in enumerate(ch.lines):
        for cat, rx in _SAFETY_RE.items():
            m = rx.search(ln)
            if m:
                hits.append(
                    {"chapter": ch.title, "line_no": i + 1, "category": cat, "hit": m.group(0), "text": ln[:60]}
                )
    return hits


def scan_format(ch: Chapter) -> list[dict]:
    """格式类：繁体、乱码、空章（对应官方「内容格式有误」）。"""
    out = []
    trad = [c for c in ch.text if c in _TRAD_ONLY]
    if len(trad) >= 10:
        out.append({"chapter": ch.title, "issue": "疑似繁体字", "count": len(trad), "sample": "".join(dict.fromkeys(trad))[:20]})
    weird = [c for c in ch.text if not _is_allowed_char(c)]
    if len(weird) >= 10:
        out.append({"chapter": ch.title, "issue": "疑似乱码/异常字符", "count": len(weird), "sample": "".join(dict.fromkeys(weird))[:20]})
    if ch.chars < 50:
        out.append({"chapter": ch.title, "issue": "空章或极短章", "chars": ch.chars})
    return out


# ---------- 通用高频短语（不预设词表） ----------

def high_freq_grams(chapters: list[Chapter], n: int = 4, min_count: int | None = None) -> list[tuple[str, int]]:
    """全书高频 n-gram（不预设词表）。min_count 默认 max(30, 章节数*0.2)，随书规模自适应。"""
    if min_count is None:
        min_count = max(30, int(len(chapters) * 0.2))
    c = Counter()
    for ch in chapters:
        c.update(ngrams(ch.body_norm, n))
    return [(g, k) for g, k in c.most_common() if k >= min_count]


def recurring_lines(chapters: list[Chapter], min_chars: int = 12, min_count: int = 2) -> dict[str, list[dict]]:
    """跨章逐字重复的长行（判"刻意注水"的主证据）。返回 norm → 出现位置列表。"""
    idx: dict[str, list[dict]] = {}
    for ch in chapters:
        seen = set()
        for i, ln in enumerate(ch.lines):
            k = norm(ln)
            if len(k) < min_chars or k in seen:
                continue
            seen.add(k)
            idx.setdefault(k, []).append(
                {"chapter": ch.title, "chapter_no": ch.no, "line_no": i + 1, "is_dialogue": is_dialogue(ln), "raw": ln}
            )
    return {k: v for k, v in idx.items() if len(v) >= min_count}


def within_chapter_dups(ch: Chapter, min_chars: int = 8) -> dict[str, list[int]]:
    """同一章内逐字重复的行（norm → 行号列表，按出现顺序）。"""
    seen: dict[str, list[int]] = {}
    for i, ln in enumerate(ch.lines):
        k = norm(ln)
        if len(k) >= min_chars:
            seen.setdefault(k, []).append(i + 1)
    return {k: v for k, v in seen.items() if len(v) > 1}


def ttr(values: list[str]) -> float:
    if not values:
        return 0.0
    return len(set(values)) / len(values)
