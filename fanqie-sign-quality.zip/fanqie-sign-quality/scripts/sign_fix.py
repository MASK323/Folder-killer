# -*- coding: utf-8 -*-
"""番茄签约质量整改器（通用）。

用法:
    python sign_fix.py "小说目录" [--out "小说目录_签约优化"] [--dry-run] [--no-audit]

自动整改只做两类**只缩短、不改写、不删除**的操作，改坏原文的风险最低：
    F1 跨章逐字重复的长行（≥12字、全书≥2次、非对话行）：保留首次，其余压缩成不重复的前缀句；
    F2 整行套话（"他点了点头。"这类，全书高频）：全书第一处保留，其余轮换替换为同功能的动作句；
    F4 章内逐字重复行（≥8字）：保留首次，其余压缩成不重复的前缀句。

压缩不出唯一前缀的，**一律不动原文**，转人工清单（附建议）。
跨章近重复（同情节重讲）、结局复述、内容安全、创新性、<1000字章：只出清单，绝不自动改。
原文件永不修改；输出写到 --out 指定目录。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fqcommon import (  # noqa: E402
    discover_chapters,
    is_dialogue,
    jaccard,
    norm,
    recurring_lines,
    set_ngrams,
    within_chapter_dups,
)

# 两章相似度超过此值 = 「同一场景重讲」，其间的重复内容一律转人工（合并或重写），
# 因为机器截断会切掉必要信息，把章节改残。
SCENE_DUP_JACCARD = 0.10

# ---------------- F2: 通用语义族（不依赖人物名/题材） ----------------

FAMILIES = [
    # (族名, 整行匹配: 主语 + 谓语, 谓语替换池)
    (
        "应答",
        re.compile(r"^(?P<subj>[\u4e00-\u9fff]{1,4}?)(?P<pred>点了点头|点头|点了下头|颔首|应了一声|应了)$"),
        ["应了一声", "把话应下了", "没再多说", "垂了下眼", "嗯了一声", "把这事记下了", "没急着开口", "把茶杯放下"],
    ),
    (
        "沉默",
        re.compile(r"^(?P<subj>[\u4e00-\u9fff]{1,4}?)(?P<pred>没有说话|没说话|没有开口|没开口|没接话|没吭声|沉默了一会儿|沉默了片刻|沉默了一下|沉默着)$"),
        ["没往下接", "把话咽了回去", "没有答话", "静了一会儿", "没再出声", "把这句话搁下了", "等着对方往下说", "没有表态"],
    ),
    (
        "视线",
        re.compile(r"^(?P<subj>[\u4e00-\u9fff]{1,4}?)(?P<pred>看了一眼|扫了一眼|看了一眼|收回目光|收回视线|抬眼看|抬眼)$"),
        ["目光停了一瞬", "把视线挪开", "扫过那一处", "没再看", "抬眼扫过", "把目光收了回来", "视线落回原处", "看了两眼"],
    ),
]

# 前缀池：与谓语组合出足够多的变体，避免"改完还是同一句"
PREFIXES = ["", "只是", "只", "却只", "顿了顿，", "听了这话，", "片刻后，", "没有再说什么，", "没有催促，", "沉默了一下，"]

# 人工清单里的改写建议（仅作为提示，脚本不会自动写入正文）
SUGGESTIONS = [
    "这些事，他在心里过了很多遍。",
    "他把念头压了下去。",
    "他不敢想得太远。",
    "念头到这里就断了。",
    "剩下的，他早就想清楚了。",
    "他没让自己再想下去。",
    "他不再去想这些。",
    "有些事，想也没用。",
    "他把心思收回来。",
    "这话他记下了。",
    "到这一步，退不回去了。",
    "他比谁都清楚这一点。",
]

MIN_CHAPTER_CHARS = 1000
DUP_MIN_CHARS = 12       # 跨章重复判定阈值（官方发布门槛是 ≥15 字，这里取 12 覆盖 14 字模板句）
INNER_MIN_CHARS = 8      # 章内重复判定阈值
SENT_SPLIT = re.compile(r"(?<=[。！？…])")


def extract_subject(line: str):
    """返回 (subject, family_name)；整行必须是 主语+谓语 结构才算命中。"""
    stripped = line.strip().rstrip("。！？…").replace("，", "").replace(" ", "")
    for name, rx, _pool in FAMILIES:
        m = rx.match(stripped)
        if m:
            return m.group("subj"), name
    return None, None


def family_pool(name):
    for n, _rx, pool in FAMILIES:
        if n == name:
            return pool
    return []


def make_prefix(raw: str, used: set[str], min_len: int = 8) -> str | None:
    """把重复行压缩成"前若干个整句"，保证不与其他行逐字相同。

    只按整句边界压缩（绝不从句子中间截断），且只缩短、不改写、不新增内容。
    找不到唯一前缀时返回 None —— 调用方必须保持原文不动，转人工清单。
    """
    clauses = [c for c in SENT_SPLIT.split(raw) if c.strip()]
    for k in range(1, len(clauses)):
        cand = "".join(clauses[:k]).strip()
        n = norm(cand)
        if len(n) >= min_len and n not in used:
            return cand
    return None


def fix_chapters(chs, dry_run: bool):
    used = {norm(ln) for c in chs for ln in c.lines}
    log, manual = [], []

    # F1 跨章逐字重复长行
    sh = {c.no: set_ngrams(c.text, 3) for c in chs}
    rec = recurring_lines(chs, min_chars=DUP_MIN_CHARS, min_count=2)
    rep_by_chapter: dict[str, set[str]] = {}
    for k, locs in rec.items():
        involved = sorted({x["chapter_no"] for x in locs})
        scene_dup = any(
            jaccard(sh[a], sh[b]) > SCENE_DUP_JACCARD
            for i, a in enumerate(involved)
            for b in involved[i + 1 :]
        )
        if any(x["is_dialogue"] for x in locs):
            manual.append(
                {
                    "rule": "F1-对话豁免",
                    "reason": "重复行含引号（可能是刻意的口头禅/对话），不自动改",
                    "text": k[:60],
                    "locations": [f"{x['chapter']}:{x['line_no']}" for x in locs],
                }
            )
            continue
        if scene_dup:
            manual.append(
                {
                    "rule": "F1-整场景重复",
                    "reason": "重复出现在高相似章节之间（两章在讲同一件事），必须人工合并或重写整段，机器截断会把章节改残",
                    "text": k[:60],
                    "locations": [f"{x['chapter']}:{x['line_no']}" for x in locs],
                }
            )
            continue
        for loc in locs[1:]:
            rep_by_chapter.setdefault(loc["chapter"], set()).add(loc["raw"])

    # F2 整行套话（全书口径：第一处保留，其余轮换替换）
    short = Counter(norm(ln) for c in chs for ln in c.lines if 2 <= len(norm(ln)) <= 10)
    tic_thr = max(8, int(len(chs) * 0.03))
    tic_norms = {k for k, v in short.items() if v >= tic_thr}
    fam_counter = Counter()

    out = []
    for c in chs:
        lines = list(c.lines)
        changed = 0
        # --- F4 章内重复行（保留首次；压缩优先，压缩不了则删除重复份）---
        inner = within_chapter_dups(c, min_chars=INNER_MIN_CHARS)
        if inner:
            seen_norm: dict[str, int] = {}
            new_lines = []
            for ln in lines:
                k = norm(ln)
                if len(k) >= INNER_MIN_CHARS and k in inner:
                    seen_norm[k] = seen_norm.get(k, 0) + 1
                    if seen_norm[k] > 1 and not is_dialogue(ln):
                        cand = make_prefix(ln, used)
                        if cand is None:
                            # 章内重复：删掉重复份不会丢信息（首份仍在同一章内），
                            # 但若该行是刻意的排比/呼应，需作者复核 —— 统一记入日志。
                            log.append(
                                {
                                    "chapter": c.title,
                                    "rule": "F4-删重复份",
                                    "before": ln[:80],
                                    "after": "",
                                    "note": "章内逐字重复，已删除重复份（首份保留）；若为刻意排比请复核",
                                }
                            )
                            changed += 1
                            continue
                        new_lines.append(cand)
                        used.add(norm(cand))
                        log.append({"chapter": c.title, "rule": "F4-压缩", "before": ln[:80], "after": cand[:80]})
                        changed += 1
                        continue
                new_lines.append(ln)
            lines = new_lines
        # --- F1 跨章重复行 ---
        # 策略：模板型重复（全书出现 ≥3 次）直接删除后续份——纯冗余，删了不丢信息；
        #       只出现 2 次的可能是"共享的一个桥段"，压缩优先，压缩不了转人工。
        targets = rep_by_chapter.get(c.title, set())
        if targets:
            new_lines = []
            for ln in lines:
                if ln in targets:
                    group = rec.get(norm(ln), [])
                    template = len(group) >= 3
                    cand = make_prefix(ln, used)
                    if cand is not None:
                        new_lines.append(cand)
                        used.add(norm(cand))
                        log.append({"chapter": c.title, "rule": "F1-压缩", "before": ln[:80], "after": cand[:80]})
                        changed += 1
                    elif template:
                        log.append(
                            {
                                "chapter": c.title,
                                "rule": "F1-删模板重复",
                                "before": ln[:80],
                                "after": "",
                                "note": f"该句全书出现 {len(group)} 次（模板型复盘），已删除后续份，首份保留",
                            }
                        )
                        changed += 1
                    else:
                        manual.append(
                            {
                                "rule": "F1-需人工",
                                "reason": "跨章重复且无法安全压缩（全书仅 2 次，可能是两章共享的同一桥段），需人工改写或并章",
                                "chapter": c.title,
                                "text": ln[:60],
                                "suggestion": SUGGESTIONS[len(manual) % len(SUGGESTIONS)],
                            }
                        )
                    continue
                new_lines.append(ln)
            lines = new_lines
        # --- F2 整行套话 ---
        new_lines = []
        for ln in lines:
            subj, fam = extract_subject(ln)
            if fam and norm(ln) in tic_norms:
                fam_counter[fam] += 1
                if fam_counter[fam] > 1:  # 全书第一处保留
                    pool = family_pool(fam)
                    replaced = False
                    for pi, prefix in enumerate(PREFIXES):
                        for qi in range(len(pool)):
                            cand = subj + prefix + pool[(fam_counter[fam] + qi + pi) % len(pool)] + "。"
                            if norm(cand) not in used:
                                new_lines.append(cand)
                                used.add(norm(cand))
                                log.append({"chapter": c.title, "rule": f"F2-{fam}", "before": ln, "after": cand})
                                changed += 1
                                replaced = True
                                break
                        if replaced:
                            break
                    if not replaced:
                        new_lines.append(ln)
                    continue
            new_lines.append(ln)
        lines = new_lines

        text = "\n".join(lines) + "\n"
        if len(norm(text)) < MIN_CHAPTER_CHARS and c.chars >= MIN_CHAPTER_CHARS:
            manual.append(
                {
                    "rule": "字数保护",
                    "reason": f"自动整改后不足 {MIN_CHAPTER_CHARS} 字，已回滚该章以免违反字数硬门槛",
                    "chapter": c.title,
                }
            )
            out.append((c, c.text, 0))
            continue
        out.append((c, text, changed))

    return out, log, manual


def main():
    ap = argparse.ArgumentParser(description="番茄签约质量整改（通用）")
    ap.add_argument("src", help="小说目录或单文件")
    ap.add_argument("--out", default=None, help="输出目录（默认 <源目录>_签约优化）")
    ap.add_argument("--dry-run", action="store_true", help="只出清单，不落盘")
    ap.add_argument("--no-audit", action="store_true", help="跳过整改前后评分对比")
    args = ap.parse_args()

    src = Path(args.src).resolve()
    chs = discover_chapters(src)
    if not chs:
        print("未发现章节文件", file=sys.stderr)
        return 2

    out_dir = Path(args.out) if args.out else src.parent / f"{src.name}_签约优化"
    fixed, log, manual = fix_chapters(chs, args.dry_run)

    total_changes = sum(x[2] for x in fixed)
    rules = Counter(x["rule"].split("-")[0] for x in log)
    print(f"章节 {len(chs)}　自动整改 {total_changes} 处（{dict(rules)}）　人工清单 {len(manual)} 条")

    if not args.dry_run:
        for c, text, changed in fixed:
            rel = c.path.relative_to(src) if src.is_dir() else Path(c.path.name)
            dst = out_dir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_text(text, encoding="utf-8")
        (out_dir / "sign_fix_log.json").write_text(
            json.dumps(
                {
                    "generated_at": datetime.now().isoformat(timespec="seconds"),
                    "policy": "只压缩/只替换整行套话；不改写、不删除、不新增情节内容",
                    "changes": log,
                    "manual": manual,
                },
                ensure_ascii=False,
                indent=1,
            ),
            encoding="utf-8",
        )
        print("已写入：" + str(out_dir))

    if not args.no_audit:
        try:
            from sign_audit import build_metrics, score

            m0 = build_metrics(chs)
            _d0, t0, v0 = score(m0)
            if not args.dry_run:
                m1 = build_metrics(discover_chapters(out_dir))
                _d1, t1, v1 = score(m1)
                print(f"评分对比：{t0}（{v0}） → {t1}（{v1}）")
            else:
                print(f"当前评分：{t0}（{v0}）")
        except Exception as e:  # noqa: BLE001
            print(f"评分对比跳过：{e}")

    if manual:
        by_rule = Counter(x["rule"] for x in manual)
        print("\n人工清单：" + json.dumps(dict(by_rule), ensure_ascii=False))
        for x in manual[:12]:
            print("  -", json.dumps(x, ensure_ascii=False)[:170])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
