# -*- coding: utf-8 -*-
"""番茄签约质量评估器（通用）。

用法:
    python sign_audit.py "小说目录" [--out 输出目录] [--json-only]

产出:
    sign_quality_report.json  全部指标与证据
    sign_quality_report.md    可读报告（结论 + 证据 + P0-P2 整改清单）

判定口径: 见 ../references/quality-rubric.md（官方判据 → 指标 → 阈值）。
本脚本只读，不修改正文。
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fqcommon import (  # noqa: E402
    cv,
    discover_chapters,
    high_freq_grams,
    is_dialogue,
    jaccard,
    ngrams,
    norm,
    recurring_lines,
    scan_format,
    scan_safety,
    set_ngrams,
    split_sentences,
    ttr,
    within_chapter_dups,
)

WEIGHTS = {"注水": 30, "结构": 20, "空洞": 20, "机械行文": 20, "合规门槛": 10}
GRADES = {"ok": 1.0, "warn": 0.6, "bad": 0.2}
LEVEL_CN = {"ok": "达标", "warn": "警戒", "bad": "不达标"}


def grade_le(v, ok, warn):
    """越小越好"""
    return "ok" if v <= ok else ("warn" if v <= warn else "bad")


def grade_ge(v, ok, warn):
    """越大越好"""
    return "ok" if v >= ok else ("warn" if v >= warn else "bad")


def build_metrics(chs):
    n = len(chs)
    m = {"chapter_count": n}
    m["total_chars_norm"] = sum(c.chars for c in chs)
    m["total_chars_raw"] = sum(len(c.text) for c in chs)
    m["avg_chapter_chars"] = round(m["total_chars_norm"] / n, 1) if n else 0

    # ---- 注水 ----
    rec_long = recurring_lines(chs, min_chars=15, min_count=2)
    rec_para = {k: v for k, v in rec_long.items() if len(k) >= 40}
    max_rep = max((len(v) for v in rec_long.values()), default=1)
    m["dup_long_lines"] = len(rec_long)                    # ≥15字逐字重复种类数
    m["dup_long_max_repeat"] = max_rep                     # 单句最大重复次数
    m["dup_paragraphs"] = len(rec_para)                    # ≥40字复述段落种类数
    m["dup_paragraph_locations"] = sum(len(v) for v in rec_para.values())
    m["chapter_len_cv"] = round(cv([c.chars for c in chs]), 3)
    inner = 0
    inner_chapters = []
    for c in chs:
        d = within_chapter_dups(c, min_chars=8)
        if d:
            inner += sum(len(v) - 1 for v in d.values())
            inner_chapters.append(c.title)
    m["within_chapter_dup_lines"] = inner              # 章内逐字重复行（多出的份数）
    m["within_chapter_dup_chapters"] = inner_chapters[:20]
    m["within_chapter_dup_chapter_count"] = len(inner_chapters)

    # ---- 结构 ----
    sh = {c.no: set_ngrams(c.text, 3) for c in chs}
    nos = [c.no for c in chs]
    # 结构失常的主证据：两章之间共享整句（≥15字逐字相同）= 同一情节重讲，而非正常的情节连贯
    shared: dict[tuple[int, int], list[str]] = {}
    for k, locs in rec_long.items():
        involved = sorted({x["chapter_no"] for x in locs})
        for i, a in enumerate(involved):
            for b in involved[i + 1 :]:
                shared.setdefault((a, b), []).append(k)
    merge_pairs = [
        {"a": a, "b": b, "shared_lines": len(ks), "shared_chars": sum(len(x) for x in ks), "sample": ks[0][:50]}
        for (a, b), ks in shared.items()
    ]
    merge_pairs.sort(key=lambda x: -x["shared_chars"])
    m["shared_line_pairs"] = len(merge_pairs)
    m["merge_suggestions"] = merge_pairs[:20]
    # 辅助指标：3-gram 相似度（含正常情节连贯，仅作参考）
    loose = 0
    for i, a in enumerate(nos):
        for b in nos[i + 1 :]:
            if abs(a - b) > 40:
                continue
            if jaccard(sh[a], sh[b]) > 0.10:
                loose += 1
    m["near_dup_pairs"] = loose
    m["near_dup_pairs_loose"] = loose
    m["near_dup_top"] = [
        {"a": a, "b": b, "jaccard": round(jaccard(sh[a], sh[b]), 3)}
        for a, b in [(p["a"], p["b"]) for p in merge_pairs[:8]]
    ]
    tail = nos[-3:] if n >= 3 else nos
    tail_j = [round(jaccard(sh[a], sh[b]), 3) for i, a in enumerate(tail) for b in tail[i + 1 :]]
    m["tail_similarity_max"] = max(tail_j) if tail_j else 0.0
    tail = nos[-3:] if n >= 3 else nos
    tail_j = [round(jaccard(sh[a], sh[b]), 3) for i, a in enumerate(tail) for b in tail[i + 1 :]]
    m["tail_similarity_max"] = max(tail_j) if tail_j else 0.0
    titles = [c.title for c in chs]
    base = Counter()
    for t in titles:
        core = t.split()[-1] if " " in t else t
        base[core] += 1
    m["title_repeat_groups"] = sum(1 for v in base.values() if v > 1)
    sizes = [c.chars for c in chs]
    m["chapter_len_min"] = min(sizes) if sizes else 0
    m["chapter_len_max"] = max(sizes) if sizes else 0
    m["chapter_len_ratio"] = round(max(sizes) / min(sizes), 2) if sizes and min(sizes) else 0

    # ---- 空洞 ----
    lines_all = [ln for c in chs for ln in c.lines]
    dlg = sum(1 for ln in lines_all if is_dialogue(ln))
    m["dialogue_ratio"] = round(dlg / len(lines_all), 3) if lines_all else 0
    grams_all = [g for c in chs for g in ngrams(c.body_norm, 4)]
    m["gram4_ttr"] = round(ttr(grams_all), 4)
    m["gram4_repeat_ratio"] = round(1 - m["gram4_ttr"], 4)  # 全书 4-gram 重复率（注水/水文的直接度量）
    per_ch_ttr = [(c.title, round(ttr(list(ngrams(c.body_norm, 4))), 4)) for c in chs]
    m["gram4_ttr_mean"] = round(sum(x[1] for x in per_ch_ttr) / len(per_ch_ttr), 4) if per_ch_ttr else 0
    low_thr = m["gram4_ttr_mean"] * 0.7
    low_ch = [t for t, v in per_ch_ttr if v < low_thr]
    m["low_info_chapters"] = len(low_ch)
    m["low_info_ratio"] = round(len(low_ch) / n, 3) if n else 0
    m["low_info_top"] = low_ch[:15]

    # ---- 机械行文 ----
    hf = high_freq_grams(chs, 4)
    m["high_freq_gram_count"] = len(hf)
    m["high_freq_grams"] = [{"gram": g, "count": k} for g, k in hf[:30]]
    # 机械行文工作清单：高频短语 + 例句，供人工逐条换成具体描写
    worklist = []
    for g, k in hf[:12]:
        samples = []
        for c in chs:
            for ln in c.lines:
                if g in norm(ln) and len(samples) < 3:
                    samples.append(f"{c.title}：{ln[:50]}")
            if len(samples) >= 3:
                break
        worklist.append({"gram": g, "count": k, "samples": samples})
    m["mechanical_worklist"] = worklist
    openers = Counter()
    for ln in lines_all:
        s = norm(ln)
        if len(s) >= 4 and not is_dialogue(ln):
            openers[s[:3]] += 1
    m["top_openers"] = openers.most_common(15)
    m["opener_max"] = openers.most_common(1)[0][1] if openers else 0
    m["opener_ratio"] = round(m["opener_max"] / n, 3) if n else 0
    sent_lens = [len(s) for c in chs for s in split_sentences(c.text)]
    m["sentence_len_cv"] = round(cv(sent_lens), 3)
    short_line_thr = max(8, int(n * 0.03))
    short_lines = Counter(norm(ln) for ln in lines_all if 2 <= len(norm(ln)) <= 10)
    tic_lines = sum(k for _, k in short_lines.most_common() if k >= short_line_thr)
    m["tic_line_ratio"] = round(tic_lines / len(lines_all), 4) if lines_all else 0
    m["tic_line_top"] = [(k, v) for k, v in short_lines.most_common(15) if v >= short_line_thr]

    # ---- 合规 ----
    under = [{"chapter": c.title, "chars": c.chars} for c in chs if c.chars < 1000]
    m["chapters_under_1000"] = len(under)
    m["under_1000_list"] = under[:15]
    long_titles = [c.title for c in chs if len(c.title) > 30]
    m["titles_over_30"] = len(long_titles)
    fmt = [x for c in chs for x in scan_format(c)]
    m["format_issues"] = fmt[:15]
    m["format_issue_count"] = len(fmt)
    safety = [x for c in chs for x in scan_safety(c)]
    m["safety_hits"] = safety[:30]
    m["safety_hit_count"] = len(safety)
    m["threshold_reached"] = {
        "2万": m["total_chars_norm"] >= 20000,
        "5万": m["total_chars_norm"] >= 50000,
        "8万": m["total_chars_norm"] >= 80000,
    }
    return m


def score(m):
    dims = {}

    # 注水 30（5 项 × 6 分）
    g = [
        grade_le(m["dup_long_lines"], 0, 5),
        grade_le(m["dup_long_max_repeat"], 2, 4),
        grade_le(m["dup_paragraphs"], 0, 0),
        grade_le(m["within_chapter_dup_lines"], 0, max(1, m["chapter_count"] * 0.02)),
        grade_ge(m["chapter_len_cv"], 0.25, 0.20),
    ]
    dims["注水"] = sum(WEIGHTS["注水"] / 5 * GRADES[x] for x in g)

    # 结构 20
    n = m["chapter_count"]
    near_ok, near_warn = n * 0.01, n * 0.03
    g = [
        grade_le(m["shared_line_pairs"], near_ok, near_warn),
        grade_le(m["tail_similarity_max"], 0.08, 0.12),
        grade_le(m["title_repeat_groups"], 0, 1),
        grade_le(m["chapter_len_ratio"], 4, 6),
    ]
    dims["结构"] = sum(WEIGHTS["结构"] / 4 * GRADES[x] for x in g)

    # 空洞 20
    d = m["dialogue_ratio"]
    dl = "ok" if 0.15 <= d <= 0.45 else ("warn" if (0.10 <= d < 0.15 or 0.45 < d <= 0.55) else "bad")
    g = [
        dl,
        grade_le(m["gram4_repeat_ratio"], 0.10, 0.20),   # 4-gram 重复率：越低越不水
        grade_le(m["low_info_ratio"], 0.05, 0.12),
        grade_ge(m["avg_chapter_chars"], 1500, 1000),
    ]
    dims["空洞"] = sum(WEIGHTS["空洞"] / 4 * GRADES[x] for x in g)

    # 机械行文 20
    g = [
        grade_le(m["high_freq_gram_count"], 3, 8),
        grade_le(m["opener_ratio"], 0.3, 0.5),
        grade_ge(m["sentence_len_cv"], 0.55, 0.40),
        grade_le(m["tic_line_ratio"], 0.01, 0.03),
    ]
    dims["机械行文"] = sum(WEIGHTS["机械行文"] / 4 * GRADES[x] for x in g)

    # 合规门槛 10
    c1 = "ok" if m["chapters_under_1000"] == 0 else ("warn" if m["chapters_under_1000"] <= max(1, n * 0.02) else "bad")
    c2 = "ok" if (m["titles_over_30"] == 0 and m["format_issue_count"] == 0) else "bad"
    dims["合规门槛"] = WEIGHTS["合规门槛"] / 2 * GRADES[c1] + WEIGHTS["合规门槛"] / 2 * GRADES[c2]

    total = round(sum(dims.values()), 1)
    verdict = "可提交" if total >= 85 else ("需整改" if total >= 70 else "不满足官方质量要求，先整改")
    return dims, total, verdict


def build_fixes(m):
    p0, p1, p2 = [], [], []
    if m["dup_paragraph_locations"] > 0:
        p0.append(
            f"刻意注水（最硬）：全书有 {m['dup_paragraphs']} 种 ≥40 字段落逐字复述，"
            f"共 {m['dup_paragraph_locations']} 处。处理：只保留首次，其余全部差异化或删除。"
        )
    if m["dup_long_lines"] > 0:
        p0.append(
            f"逐字重复长句（≥15字）{m['dup_long_lines']} 种，单句最高重复 {m['dup_long_max_repeat']} 次。"
            f"处理：跑 sign_fix.py 自动压缩/删除，再人工通读接顺。"
        )
    if m["near_dup_pairs"] > 0:
        p0.append(
            f"结构失常：相邻章节高相似 {m['near_dup_pairs']} 对（口径：3-gram Jaccard>0.10，含正常情节连贯，仅作参考）。"
        )
    if m["shared_line_pairs"] > 0:
        top = m["merge_suggestions"][0] if m["merge_suggestions"] else None
        p0.append(
            f"同情节重讲：{m['shared_line_pairs']} 对章节之间存在≥15字整句逐字复制"
            + (f"（最严重 第{top['a']}章↔第{top['b']}章，共享 {top['shared_lines']} 句 / {top['shared_chars']} 字）" if top else "")
            + "。处理：二选一重写或并章，见报告「合并建议」。"
        )
    if m["within_chapter_dup_lines"] > 0:
        p0.append(
            f"注水：{m['within_chapter_dup_chapter_count']} 章存在章内逐字重复行（多出 {m['within_chapter_dup_lines']} 份）。"
            f"处理：sign_fix.py 自动保留首次、压缩其余。"
        )
    if m["tail_similarity_max"] > 0.08:
        p0.append(
            f"结局复述：末三章互相相似度 {m['tail_similarity_max']}（官方「故事完整不烂尾」）。"
            f"处理：结局三章合一，删掉重复收束，重写收尾。"
        )
    if m["high_freq_gram_count"] > 3:
        top = "、".join(f"{g}×{k}" for g, k in [(x["gram"], x["count"]) for x in m["high_freq_grams"][:6]])
        p0.append(f"机械行文（AI粗制滥造/句式呆板）：高频套话 {m['high_freq_gram_count']} 条（{top}）。处理：逐条换成具体动作或细节。")
    if m["dialogue_ratio"] < 0.15:
        p0.append(f"内容空洞：对话行占比仅 {m['dialogue_ratio']:.1%}（健康 15%–45%）。处理：把叙述总结改成场景对抗与对话。")
    if m["gram4_repeat_ratio"] > 0.20:
        p0.append(
            f"内容空洞：全书 4-gram 重复率 {m['gram4_repeat_ratio']:.1%}（>20% 即明显水文），"
            f"同一批句式在全书反复复用。处理：按下面高频套话清单逐条替换为具体描写。"
        )
    if m["chapters_under_1000"] > 0:
        p0.append(f"合规：{m['chapters_under_1000']} 章去标点不足 1000 字，会被拦或跳过。处理：补写。")
    if m["safety_hit_count"] > 0:
        p0.append(f"内容安全：命中 {m['safety_hit_count']} 处（色情/未成年/暴力/伦理/时政/赌毒类），**必须人工逐条判断删改**，脚本不动。")
    if m["format_issue_count"] > 0:
        p0.append(f"格式：{m['format_issue_count']} 处格式问题（繁体/乱码/空章），对应官方「内容格式有误」。")

    if m["chapter_len_cv"] < 0.25:
        p1.append(f"章节字数过于均匀（CV={m['chapter_len_cv']}，偏低），是机器生成特征。处理：删减凑数段落，让章节随情节起伏。")
    if m["low_info_ratio"] > 0.05:
        p1.append(f"低信息量章节占比 {m['low_info_ratio']:.1%}（{m['low_info_chapters']} 章）。处理：并章或补实体冲突。")
    if m["tic_line_ratio"] > 0.01:
        p1.append(f"整行套话占比 {m['tic_line_ratio']:.2%}。处理：sign_fix.py 自动轮换替换为具体动作。")
    if m["opener_ratio"] > 0.3:
        p1.append(f"段首模板化：最高频段首出现 {m['opener_max']} 次（占章数 {m['opener_ratio']:.0%}）。处理：变换句式与段首。")
    if m["sentence_len_cv"] < 0.55:
        p1.append(f"句长变异系数 {m['sentence_len_cv']} 偏低（句式呆板）。处理：长短句交错。")
    if m["title_repeat_groups"] > 0:
        p1.append(f"章节标题重复/近似 {m['title_repeat_groups']} 组。处理：改题或并章。")

    p2.append("人工必做·开篇创新性（官方明写）：把全书最新意的设定提到第 1 章作为主事件，删减买卖/赶路/算计类日常到 1/3 以下。")
    p2.append("人工必做·立意：明确主角核心矛盾与价值选择，避免纯升级流水账。")
    p2.append("人工必做·封面书名：完本签约要求「非默认书名和封面」，封面须含书名、作者名且与书本信息一致。")
    p2.append("提交策略：连载模式 2万/5万/8万字各有一次机会；整本一次性灌入会与《低质治理公告》打击的批量特征重合，建议按日更节奏发布。")
    if not m["threshold_reached"]["2万"]:
        p2.append("当前字数未达 2 万字，尚不具备申请签约资格。")
    return p0, p1, p2


def render_md(m, dims, total, verdict, p0, p1, p2, src):
    L = []
    L.append("# 番茄小说签约质量评估报告")
    L.append("")
    L.append(f"- 评估对象：`{src}`")
    L.append(f"- 评估时间：{datetime.now():%Y-%m-%d %H:%M}")
    L.append(f"- 规模：{m['chapter_count']} 章 / {m['total_chars_norm']:,} 字（去标点）/ 平均 {m['avg_chapter_chars']} 字每章")
    L.append("")
    L.append(f"## 结论：**{verdict}**　总分 **{total} / 100**")
    L.append("")
    L.append("| 维度 | 得分 | 权重 |")
    L.append("|------|------|------|")
    for k, w in WEIGHTS.items():
        L.append(f"| {k} | {dims[k]:.1f} | {w} |")
    L.append("")
    L.append("> 判定口径来自官方《签约评估标准》《低质治理公告》，映射见 `references/quality-rubric.md`。")
    L.append("> 提交前阈值：总分 ≥85 且 P0 为 0。官方规则：质量评估不通过后只剩 2 次修改重交机会。")
    L.append("")
    L.append("## 一、官方判据逐条判定")
    L.append("")
    L.append("| 官方判据 | 指标 | 实测 | 判定 |")
    L.append("|---------|------|------|------|")
    rows = [
        ("刻意注水", "≥15字逐字重复长句种类", m["dup_long_lines"], grade_le(m["dup_long_lines"], 0, 5)),
        ("刻意注水", "单句最大重复次数", m["dup_long_max_repeat"], grade_le(m["dup_long_max_repeat"], 2, 4)),
        ("刻意注水", "≥40字复述段落（种类/落点）", f"{m['dup_paragraphs']} / {m['dup_paragraph_locations']}", grade_le(m["dup_paragraphs"], 0, 0)),
        ("刻意注水", "章内逐字重复行", m["within_chapter_dup_lines"], grade_le(m["within_chapter_dup_lines"], 0, max(1, m["chapter_count"] * 0.02))),
        ("刻意注水", "章节字数 CV", m["chapter_len_cv"], grade_ge(m["chapter_len_cv"], 0.25, 0.20)),
        ("结构失常", "共享整句的章节对（同情节重讲）", m["shared_line_pairs"], grade_le(m["shared_line_pairs"], m["chapter_count"] * 0.01, m["chapter_count"] * 0.03)),
        ("结构失常", "3-gram 高相似对（参考）", m["near_dup_pairs"], "ok" if m["near_dup_pairs"] <= m["chapter_count"] * 0.05 else "warn"),
        ("结构失常", "末三章互相相似度", m["tail_similarity_max"], grade_le(m["tail_similarity_max"], 0.08, 0.12)),
        ("结构失常", "章长极值比", m["chapter_len_ratio"], grade_le(m["chapter_len_ratio"], 4, 6)),
        ("结构失常", "标题重复组", m["title_repeat_groups"], grade_le(m["title_repeat_groups"], 0, 1)),
        ("内容空洞", "对话行占比", f"{m['dialogue_ratio']:.1%}", "ok" if 0.15 <= m["dialogue_ratio"] <= 0.45 else "bad"),
        ("内容空洞", "4-gram 重复率", f"{m['gram4_repeat_ratio']:.1%}", grade_le(m["gram4_repeat_ratio"], 0.10, 0.20)),
        ("内容空洞", "低信息章节占比", f"{m['low_info_ratio']:.1%}", grade_le(m["low_info_ratio"], 0.05, 0.12)),
        ("机械行文", "高频套话条数", m["high_freq_gram_count"], grade_le(m["high_freq_gram_count"], 3, 8)),
        ("机械行文", "整行套话占比", f"{m['tic_line_ratio']:.2%}", grade_le(m["tic_line_ratio"], 0.01, 0.03)),
        ("机械行文", "句长变异系数", m["sentence_len_cv"], grade_ge(m["sentence_len_cv"], 0.55, 0.40)),
        ("机械行文", "段首模板最高频次", f"{m['opener_max']}（{m['opener_ratio']:.0%} 章数）", grade_le(m["opener_ratio"], 0.3, 0.5)),
        ("合规门槛", "<1000字章节", m["chapters_under_1000"], grade_le(m["chapters_under_1000"], 0, max(1, m["chapter_count"] * 0.02))),
        ("合规门槛", "标题超30字/格式问题", f"{m['titles_over_30']} / {m['format_issue_count']}", "ok" if (m["titles_over_30"] == 0 and m["format_issue_count"] == 0) else "bad"),
        ("内容安全", "敏感类命中", m["safety_hit_count"], grade_le(m["safety_hit_count"], 0, 0)),
    ]
    for a, b, c, g in rows:
        L.append(f"| {a} | {b} | {c} | {LEVEL_CN[g]} |")
    L.append("")
    L.append("## 二、证据明细")
    L.append("")
    L.append("**1. 逐字重复长句 TOP（官方「刻意注水」）**")
    L.append("")
    for item in sorted(m.get("dup_evidence", [])[:12], key=lambda x: -x["count"]):
        loc = "、".join(x["chapter"] for x in item["locations"][:12])
        L.append(f"- ×{item['count']}　`{item['text'][:50]}`　→ {loc}")
    if not m.get("dup_evidence"):
        L.append("- 无")
    L.append("")
    L.append("**2. 高频套话（官方「AI粗制滥造 / 句式呆板」）—— 逐条改的工作清单**")
    L.append("")
    for w in m.get("mechanical_worklist", [])[:10]:
        L.append(f"- **{w['gram']}** ×{w['count']}　目标：降到 ≤ {max(5, m['chapter_count'] // 10)} 次")
        for s in w["samples"]:
            L.append(f"    - {s}")
    L.append("")
    L.append("**3. 合并建议（同情节重讲，官方「结构失常」）**")
    L.append("")
    if m["merge_suggestions"]:
        L.append("| 章节对 | 共享整句 | 共享字数 | 样例（逐字相同） |")
        L.append("|--------|---------|---------|------------------|")
        for s in m["merge_suggestions"][:10]:
            L.append(f"| 第{s['a']:03d}章 ↔ 第{s['b']:03d}章 | {s['shared_lines']} | {s['shared_chars']} | `{s['sample']}` |")
    else:
        L.append("无")
    L.append("")
    L.append("**4. 低信息量章节**")
    L.append("")
    L.append("　" + "、".join(m["low_info_top"]) if m["low_info_top"] else "　无")
    L.append("")
    if m["within_chapter_dup_chapters"]:
        L.append("**5. 章内重复行所在章节**")
        L.append("")
        L.append("　" + "、".join(m["within_chapter_dup_chapters"]))
        L.append("")
    if m["safety_hits"]:
        L.append("**6. 内容安全命中（必须人工判断）**")
        L.append("")
        for h in m["safety_hits"][:20]:
            L.append(f"- [{h['category']}] {h['chapter']} 第{h['line_no']}行：…{h['text']}…")
        L.append("")
    L.append("## 三、整改清单")
    L.append("")
    L.append("### P0（不达标，提交前必须全部处理）")
    L.append("")
    if p0:
        for i, x in enumerate(p0, 1):
            L.append(f"{i}. {x}")
    else:
        L.append("无")
    L.append("")
    L.append("### P1（警戒项）")
    L.append("")
    if p1:
        for i, x in enumerate(p1, 1):
            L.append(f"{i}. {x}")
    else:
        L.append("无")
    L.append("")
    L.append("### P2（人工必做 / 策略）")
    L.append("")
    for i, x in enumerate(p2, 1):
        L.append(f"{i}. {x}")
    L.append("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="番茄签约质量评估（通用）")
    ap.add_argument("src", help="小说目录或单文件")
    ap.add_argument("--out", default=None, help="报告输出目录（默认写到源目录同级 _签约评估）")
    ap.add_argument("--json-only", action="store_true")
    args = ap.parse_args()

    src = Path(args.src).resolve()
    chs = discover_chapters(src)
    if not chs:
        print("未发现章节文件（.txt/.md）", file=sys.stderr)
        return 2

    m = build_metrics(chs)
    rec = recurring_lines(chs, min_chars=15, min_count=2)
    m["dup_evidence"] = [
        {"text": k, "count": len(v), "locations": v}
        for k, v in sorted(rec.items(), key=lambda kv: -len(kv[1]))[:25]
    ]
    dims, total, verdict = score(m)
    p0, p1, p2 = build_fixes(m)

    out_dir = Path(args.out) if args.out else src.parent / f"{src.name}_签约评估"
    out_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "source": str(src),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "metrics": m,
        "scores": {**{k: round(v, 1) for k, v in dims.items()}, "total": total},
        "verdict": verdict,
        "fixes": {"P0": p0, "P1": p1, "P2": p2},
    }
    (out_dir / "sign_quality_report.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    md_path = out_dir / "sign_quality_report.md"
    if not args.json_only:
        md_path.write_text(render_md(m, dims, total, verdict, p0, p1, p2, src), encoding="utf-8")

    print(f"章节 {m['chapter_count']} / 字数 {m['total_chars_norm']:,}（去标点）")
    print("分项：" + "　".join(f"{k} {v:.1f}/{WEIGHTS[k]}" for k, v in dims.items()))
    print(f"总分 {total} → {verdict}")
    print(f"P0 {len(p0)} 项 / P1 {len(p1)} 项 / P2 {len(p2)} 项")
    print("报告：" + str(out_dir / "sign_quality_report.json"))
    if not args.json_only:
        print("　　　" + str(md_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
