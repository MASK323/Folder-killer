#!/bin/bash
# 打包所有小说写作skills
# 用法: bash package-skills.sh [输出目录]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
OUTPUT_DIR="${1:-$SKILL_DIR/../../../小说/skills-package}"

echo "=== 小说写作Skills打包工具 ==="
echo "源目录: $SKILL_DIR"
echo "输出目录: $OUTPUT_DIR"
echo ""

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 要打包的skills列表
SKILLS=(
    "story"
    "story-long-write"
    "story-long-analyze"
    "story-long-scan"
    "story-short-write"
    "story-short-analyze"
    "story-short-scan"
    "story-deslop"
    "story-import"
    "story-review"
    "story-cover"
    "story-setup"
    "browser-cdp"
    "novel-punctuation"
    "novel-content-safety"
)

# 复制skills
echo "正在复制skills..."
for skill in "${SKILLS[@]}"; do
    src="$SKILL_DIR/$skill"
    dst="$OUTPUT_DIR/$skill"
    if [ -d "$src" ]; then
        cp -r "$src" "$dst"
        echo "  ✓ $skill"
    else
        echo "  ✗ $skill (不存在)"
    fi
done

# 复制README
if [ -f "$SKILL_DIR/../README.md" ]; then
    cp "$SKILL_DIR/../README.md" "$OUTPUT_DIR/"
    echo "  ✓ README.md"
fi

# 创建ZIP包
echo ""
echo "正在创建ZIP包..."
cd "$OUTPUT_DIR/.."
zip -r "novel-writing-skills.zip" "$(basename "$OUTPUT_DIR")" -x "*.DS_Store" "*__pycache__*"
echo "  ✓ ZIP包已创建: $(pwd)/novel-writing-skills.zip"

# 统计
echo ""
echo "=== 打包完成 ==="
echo "包含的skills: ${#SKILLS[@]}个"
echo "输出目录: $OUTPUT_DIR"
echo "ZIP包: $(pwd)/novel-writing-skills.zip"
echo ""
echo "使用方法:"
echo "  1. 解压ZIP包到目标目录"
echo "  2. 在ZCode中调用 /story-* 使用对应功能"
echo "  3. 调用 /novel-punctuation 检查标点格式"
echo "  4. 调用 /novel-content-safety 进行内容安全检查"
