#!/usr/bin/env python3
"""
元宝平台小说导出工具
支持导出为 txt、docx、md 格式

用法:
    python export-to-yuanbao.py --input <小说目录> --output <输出目录> --format <格式>
    
示例:
    python export-to-yuanbao.py --input "E:\AIprojiect\小说\章节定稿" --output "E:\AIprojiect\小说\导出" --format txt
    python export-to-yuanbao.py --input "E:\AIprojiect\小说\章节定稿" --output "E:\AIprojiect\小说\导出" --format docx
    python export-to-yuanbao.py --input "E:\AIprojiect\小说\章节定稿" --output "E:\AIprojiect\小说\导出" --format all
"""

import os
import re
import argparse
from pathlib import Path
from datetime import datetime


def extract_chapters(input_dir):
    """从目录中提取章节内容"""
    chapters = []
    
    # 遍历所有卷
    for volume_dir in sorted(Path(input_dir).iterdir()):
        if volume_dir.is_dir() and volume_dir.name.startswith("第"):
            volume_name = volume_dir.name
            
            # 遍历章节文件
            for chapter_file in sorted(volume_dir.glob("*.txt")):
                # 提取章节号
                match = re.search(r'第(\d+)章', chapter_file.name)
                if match:
                    chapter_num = int(match.group(1))
                    
                    # 读取章节内容
                    with open(chapter_file, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                    
                    # 提取章节标题（第一行）
                    lines = content.split('\n')
                    title = lines[0].strip() if lines else chapter_file.stem
                    
                    # 提取正文（去掉标题）
                    body = '\n'.join(lines[1:]).strip() if len(lines) > 1 else content
                    
                    chapters.append({
                        'num': chapter_num,
                        'title': title,
                        'volume': volume_name,
                        'content': body,
                        'file': chapter_file.name
                    })
    
    # 按章节号排序
    chapters.sort(key=lambda x: x['num'])
    return chapters


def export_txt(chapters, output_path, book_title="小说"):
    """导出为TXT格式"""
    output_file = Path(output_path) / f"{book_title}.txt"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        # 写入书名
        f.write(f"{'='*50}\n")
        f.write(f"{book_title}\n")
        f.write(f"{'='*50}\n\n")
        
        current_volume = None
        for chapter in chapters:
            # 写入卷标题
            if chapter['volume'] != current_volume:
                current_volume = chapter['volume']
                f.write(f"\n{'─'*30}\n")
                f.write(f"{current_volume}\n")
                f.write(f"{'─'*30}\n\n")
            
            # 写入章节
            f.write(f"第{chapter['num']}章 {chapter['title']}\n\n")
            f.write(f"{chapter['content']}\n\n")
            f.write(f"{'─'*20}\n\n")
    
    print(f"✓ TXT导出完成: {output_file}")
    return output_file


def export_docx(chapters, output_path, book_title="小说"):
    """导出为DOCX格式"""
    try:
        from docx import Document
        from docx.shared import Pt, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        print("✗ 需要安装python-docx: pip install python-docx")
        return None
    
    output_file = Path(output_path) / f"{book_title}.docx"
    
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    font = style.font
    font.name = '宋体'
    font.size = Pt(12)
    
    # 添加封面
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title_para.add_run(book_title)
    title_run.font.size = Pt(28)
    title_run.bold = True
    
    doc.add_page_break()
    
    # 添加目录占位
    toc_para = doc.add_paragraph()
    toc_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    toc_run = toc_para.add_run("目 录")
    toc_run.font.size = Pt(18)
    toc_run.bold = True
    
    current_volume = None
    for chapter in chapters:
        # 卷标题
        if chapter['volume'] != current_volume:
            current_volume = chapter['volume']
            doc.add_paragraph()
            volume_para = doc.add_paragraph()
            volume_run = volume_para.add_run(current_volume)
            volume_run.font.size = Pt(16)
            volume_run.bold = True
        
        # 章节标题
        chapter_para = doc.add_paragraph()
        chapter_run = chapter_para.add_run(f"第{chapter['num']}章 {chapter['title']}")
        chapter_run.font.size = Pt(14)
    
    doc.add_page_break()
    
    # 写入正文
    current_volume = None
    for chapter in chapters:
        # 卷分隔
        if chapter['volume'] != current_volume:
            current_volume = chapter['volume']
            volume_para = doc.add_paragraph()
            volume_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            volume_run = volume_para.add_run(f"\n\n{current_volume}\n\n")
            volume_run.font.size = Pt(18)
            volume_run.bold = True
            doc.add_page_break()
        
        # 章节标题
        title_para = doc.add_paragraph()
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title_para.add_run(f"第{chapter['num']}章 {chapter['title']}")
        title_run.font.size = Pt(16)
        title_run.bold = True
        
        doc.add_paragraph()
        
        # 正文内容
        paragraphs = chapter['content'].split('\n')
        for para_text in paragraphs:
            if para_text.strip():
                para = doc.add_paragraph()
                para.paragraph_format.first_line_indent = Pt(24)
                run = para.add_run(para_text.strip())
                run.font.size = Pt(12)
        
        doc.add_paragraph()
    
    doc.save(output_file)
    print(f"✓ DOCX导出完成: {output_file}")
    return output_file


def export_md(chapters, output_path, book_title="小说"):
    """导出为Markdown格式"""
    output_file = Path(output_path) / f"{book_title}.md"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        # 写入标题
        f.write(f"# {book_title}\n\n")
        f.write(f"---\n\n")
        
        # 写入目录
        f.write("## 目录\n\n")
        current_volume = None
        for chapter in chapters:
            if chapter['volume'] != current_volume:
                current_volume = chapter['volume']
                f.write(f"\n### {current_volume}\n\n")
            f.write(f"- [第{chapter['num']}章 {chapter['title']}](#第{chapter['num']}章-{chapter['title']})\n")
        
        f.write(f"\n---\n\n")
        
        # 写入正文
        current_volume = None
        for chapter in chapters:
            # 卷分隔
            if chapter['volume'] != current_volume:
                current_volume = chapter['volume']
                f.write(f"\n## {current_volume}\n\n")
            
            # 章节标题
            f.write(f"### 第{chapter['num']}章 {chapter['title']}\n\n")
            
            # 正文内容
            f.write(f"{chapter['content']}\n\n")
            f.write(f"---\n\n")
    
    print(f"✓ MD导出完成: {output_file}")
    return output_file


def main():
    parser = argparse.ArgumentParser(description='元宝平台小说导出工具')
    parser.add_argument('--input', '-i', required=True, help='小说目录路径')
    parser.add_argument('--output', '-o', default=None, help='输出目录路径')
    parser.add_argument('--format', '-f', default='all', choices=['txt', 'docx', 'md', 'all'], 
                        help='导出格式 (默认: all)')
    parser.add_argument('--title', '-t', default='小说', help='书名 (默认: 小说)')
    
    args = parser.parse_args()
    
    input_dir = Path(args.input)
    output_dir = Path(args.output) if args.output else input_dir.parent / "导出元宝"
    
    # 创建输出目录
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"="*50)
    print(f"元宝平台小说导出工具")
    print(f"="*50)
    print(f"输入目录: {input_dir}")
    print(f"输出目录: {output_dir}")
    print(f"导出格式: {args.format}")
    print(f"书名: {args.title}")
    print()
    
    # 提取章节
    print("正在提取章节...")
    chapters = extract_chapters(input_dir)
    print(f"✓ 共提取 {len(chapters)} 个章节")
    
    if not chapters:
        print("✗ 未找到任何章节")
        return
    
    # 显示章节统计
    volumes = set(ch['volume'] for ch in chapters)
    print(f"✓ 共 {len(volumes)} 卷")
    print()
    
    # 导出
    exported_files = []
    
    if args.format in ['txt', 'all']:
        export_txt(chapters, output_dir, args.title)
    
    if args.format in ['docx', 'all']:
        export_docx(chapters, output_dir, args.title)
    
    if args.format in ['md', 'all']:
        export_md(chapters, output_dir, args.title)
    
    print()
    print(f"="*50)
    print(f"导出完成！")
    print(f"输出目录: {output_dir}")
    print(f"="*50)


if __name__ == '__main__':
    main()
