#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
水印定位 + 像素级去除 + 自动验证。

核心思路：AI 生成图的水印（豆包/元宝等）在"再次 AI 重绘"时会被重新打上，
因此绝不能用图生图去水印。正确做法是：
  1) 定位水印像素（差分法最准，形态学检测兜底）
  2) 用 inpaint 邻域重建抹掉
  3) OCR + 像素差分双重验证

用法：
  # 有干净参考图（推荐，AI 重绘场景总能拿到原图作 ref）
  python3 remove_watermark.py -i new.png --ref original.png -o out.png

  # 无参考图，自动在四角检测
  python3 remove_watermark.py -i img.png -o out.png

  # 手动指定区域 x0,y0,x1,y1
  python3 remove_watermark.py -i img.png -o out.png --region 1188,1673,1291,1734

  # 只看检测不落盘
  python3 remove_watermark.py -i img.png --detect-only
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import urllib.request

import cv2
import numpy as np
from PIL import Image

# ---------------------------------------------------------------- 基础工具

def load_image(path):
    """支持本地路径或 URL，统一转 BGR uint8。"""
    if path.startswith("http://") or path.startswith("https://"):
        tmp = os.path.join(tempfile.gettempdir(), "wm_dl_" + os.path.basename(path.split("?")[0]))
        urllib.request.urlretrieve(path, tmp)
        path = tmp
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    ext = os.path.splitext(path)[1].lower()
    if ext in (".webp", ".gif", ".bmp", ".tiff", ".svg"):
        im = Image.open(path).convert("RGB")
        png = os.path.splitext(path)[0] + ".png"
        im.save(png)
        path = png
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("无法读取图片: %s" % path)
    return img


def to_gray(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def candidate_regions(h, w):
    """水印常出现的候选区域：四角 + 底边中央。"""
    cw, ch = int(w * 0.30), int(h * 0.14)
    return {
        "bottom-right": (h - ch, h, w - cw, w),
        "bottom-left": (h - ch, h, 0, cw),
        "top-right": (0, ch, w - cw, w),
        "top-left": (0, ch, 0, cw),
        "bottom-center": (h - ch, h, w // 2 - cw // 2, w // 2 + cw // 2),
    }


# ---------------------------------------------------------------- 定位：差分法

def edge_distance(box, h, w):
    """区域到最近边缘的距离——水印贴边，画面主体内容不会。"""
    return min(box["y"], box["x"], h - (box["y"] + box["h"]), w - (box["x"] + box["w"]))


def corner_affinity(box, h, w):
    """
    区域中心到最近图角的距离 / min(h,w)。
    平台水印贴角（<0.20），居中的副标题/署名会很大（>0.40）。
    """
    cx, cy = box["x"] + box["w"] / 2.0, box["y"] + box["h"] / 2.0
    d = min((cx ** 2 + cy ** 2) ** 0.5,
            ((w - cx) ** 2 + cy ** 2) ** 0.5,
            (cx ** 2 + (h - cy) ** 2) ** 0.5,
            ((w - cx) ** 2 + (h - cy) ** 2) ** 0.5)
    return d / float(min(h, w))


def filter_watermark_like(boxes, h, w, edge_ratio=0.06, max_w=0.40, max_h=0.20,
                          min_area=300, corner_ratio=0.20, use_corner_rule=True):
    """
    从差分候选中筛出"像水印"的簇：贴角 + 尺寸小 + 面积够。
    这步至关重要——改书名、换副标题等主体改动同样会产生差分，
    但它们在画面中间、尺寸大，必须排除，否则会误毁画面内容。
    """
    limit = max(35, edge_ratio * min(h, w))
    scored = []
    for b in boxes:
        scored.append((edge_distance(b, h, w), b))
    scored.sort(key=lambda t: t[0])
    picked = []
    for ed, b in scored:
        if ed > limit or b["w"] > max_w * w or b["h"] > max_h * h:
            continue
        if b.get("area", 10 ** 9) < min_area:
            continue
        if use_corner_rule and corner_affinity(b, h, w) > corner_ratio:
            continue
        picked.append(b)
    strict = True
    if not picked:  # 放宽：取最贴边的一簇，但标记为低置信
        picked = [scored[0][1]] if scored else []
        strict = False
    for b in picked:
        b["edge_dist"] = edge_distance(b, h, w)
        b["corner_affinity"] = round(corner_affinity(b, h, w), 3)
        b["confident"] = strict
    return picked


def detect_by_diff(cur, ref, thr=20, min_area=50, restrict_corners=True, corner=None):
    """
    与干净参考图做差分定位。
    AI 重绘只会改水印（及用户要求改的部分），所以差分里的"贴边小簇"就是水印。
    """
    if ref.shape != cur.shape:
        ref = cv2.resize(ref, (cur.shape[1], cur.shape[0]))
    a = to_gray(cur).astype(float)
    b = to_gray(ref).astype(float)
    h, w = a.shape
    diff = np.abs(a - b)

    keep = np.zeros(diff.shape, np.uint8)
    keep[diff > thr] = 255
    if corner:
        roi = np.zeros(diff.shape, np.uint8)
        y0, y1, x0, x1 = candidate_regions(h, w)[corner]
        roi[y0:y1, x0:x1] = 255
        keep = cv2.bitwise_and(keep, roi)
    elif restrict_corners:
        roi = np.zeros(diff.shape, np.uint8)
        for (y0, y1, x0, x1) in candidate_regions(h, w).values():
            roi[y0:y1, x0:x1] = 255
        keep = cv2.bitwise_and(keep, roi)

    keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)), iterations=2)
    n, lab, stats, cent = cv2.connectedComponentsWithStats(keep, 8)
    boxes = []
    for i in range(1, n):
        x, y, ww, hh, area = stats[i]
        if area < min_area:
            continue
        boxes.append({"x": int(x), "y": int(y), "w": int(ww), "h": int(hh),
                      "area": int(area), "source": "diff"})
    boxes = merge_boxes(boxes, gap=25)
    return filter_watermark_like(boxes, h, w), diff


# ---------------------------------------------------------------- 定位：形态学检测（兜底）

def detect_by_morph(img, max_side_ratio=0.55):
    """
    无参考图时，在候选角落找"文字状"结构：
    亮笔画用 top-hat，暗笔画用 black-hat，再按连通域形态打分。
    """
    h, w = img.shape[:2]
    g = to_gray(img)
    results = []
    for name, (y0, y1, x0, x1) in candidate_regions(h, w).items():
        sub = g[y0:y1, x0:x1]
        rh, rw = sub.shape
        masks = []
        for ksize, hat in ((9, "top"), (9, "black"), (15, "top")):
            ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
            t = cv2.morphologyEx(sub, cv2.MORPH_TOPHAT, ker) if hat == "top" \
                else cv2.morphologyEx(sub, cv2.MORPH_BLACKHAT, ker)
            t = cv2.normalize(t, None, 0, 255, cv2.NORM_MINMAX)
            _, bw = cv2.threshold(t.astype("uint8"), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            masks.append(bw)
        combined = cv2.bitwise_or(cv2.bitwise_or(masks[0], masks[1]), masks[2])
        combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE,
                                    cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=2)
        n, lab, stats, cent = cv2.connectedComponentsWithStats(combined, 8)
        comps = []
        for i in range(1, n):
            x, y, ww, hh, area = stats[i]
            # 文字笔画：小面积、不过宽不过高、有一定填充率
            if area < 40 or ww > rw * max_side_ratio or hh > rh * max_side_ratio:
                continue
            if hh < 5 or ww < 4:
                continue
            fill = area / float(ww * hh)
            if fill < 0.12 or fill > 0.98:
                continue
            comps.append({"x": int(x) + x0, "y": int(y) + y0, "w": int(ww),
                          "h": int(hh), "area": int(area), "fill": round(fill, 2)})
        if not comps:
            continue
        # 聚类成"文字行"：把彼此靠近的组件合并
        clusters = cluster_comps(comps, gap=30)
        for cl in clusters:
            if len(cl) < 2:          # 单块多为画面内容，文字至少 2 个笔画块
                continue
            bx0 = min(c["x"] for c in cl)
            by0 = min(c["y"] for c in cl)
            bx1 = max(c["x"] + c["w"] for c in cl)
            by1 = max(c["y"] + c["h"] for c in cl)
            bh, bw2 = by1 - by0, bx1 - bx0
            if bh > rh * 0.6 or bw2 > rw * 0.8:
                continue
            # 评分：笔画块数量适中 + 高度一致 + 区域占比合理 + 贴边
            heights = [c["h"] for c in cl]
            h_std = float(np.std(heights)) / (float(np.mean(heights)) + 1e-6)
            score = len(cl) * 1.0 - h_std * 2.0
            if 0.03 < (bw2 * bh) / float(rw * rh) < 0.4:
                score += 2.0
            box = {"x": bx0, "y": by0, "w": bw2, "h": bh}
            ed = edge_distance(box, h, w)
            if ed <= max(35, 0.06 * min(h, w)):
                score += 3.0      # 贴边强烈提示是水印
            results.append({"region": name, "score": round(score, 2),
                            "x": bx0, "y": by0, "w": bw2, "h": bh,
                            "edge_dist": ed,
                            "n_strokes": len(cl), "source": "morph"})
    results.sort(key=lambda r: -r["score"])
    return results


def cluster_comps(comps, gap=30):
    """按空间邻近把笔画块聚成文字行。"""
    used = [False] * len(comps)
    clusters = []
    for i, c in enumerate(comps):
        if used[i]:
            continue
        group = [c]
        used[i] = True
        changed = True
        while changed:
            changed = False
            for j, d in enumerate(comps):
                if used[j]:
                    continue
                for e in group:
                    if (d["x"] - gap < e["x"] + e["w"] and e["x"] - gap < d["x"] + d["w"] and
                            d["y"] - gap < e["y"] + e["h"] and e["y"] - gap < d["y"] + d["h"]):
                        group.append(d)
                        used[j] = True
                        changed = True
                        break
        clusters.append(group)
    return clusters


def merge_boxes(boxes, gap=25):
    """把相邻 box 合并成整体水印区域。"""
    if not boxes:
        return []
    boxes = [dict(b) for b in boxes]
    merged = True
    while merged:
        merged = False
        out = []
        for b in boxes:
            hit = False
            for o in out:
                if (b["x"] - gap < o["x"] + o["w"] and o["x"] - gap < b["x"] + b["w"] and
                        b["y"] - gap < o["y"] + o["h"] and o["y"] - gap < b["y"] + b["h"]):
                    x0 = min(o["x"], b["x"]); y0 = min(o["y"], b["y"])
                    x1 = max(o["x"] + o["w"], b["x"] + b["w"])
                    y1 = max(o["y"] + o["h"], b["y"] + b["h"])
                    o.update({"x": x0, "y": y0, "w": x1 - x0, "h": y1 - y0,
                              "area": o.get("area", 0) + b.get("area", 0)})
                    hit = True
                    merged = True
                    break
            if not hit:
                out.append(b)
        boxes = out
    return boxes


# ---------------------------------------------------------------- 修复

def build_mask(shape, boxes, dilate=7, iterations=3):
    mask = np.zeros(shape[:2], np.uint8)
    for b in boxes:
        mask[b["y"]:b["y"] + b["h"], b["x"]:b["x"] + b["w"]] = 255
    if dilate > 0:
        ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dilate, dilate))
        mask = cv2.dilate(mask, ker, iterations=iterations)
    return mask


def inpaint_image(img, mask):
    """两遍 inpaint：TELEA 保结构 + NS 平滑大区域，再对边缘做羽化融合。"""
    out = cv2.inpaint(img, mask, 9, cv2.INPAINT_TELEA)
    out = cv2.inpaint(out, mask, 21, cv2.INPAINT_NS)
    # 羽化：避免修复块与原图接缝生硬
    soft = cv2.GaussianBlur(mask, (0, 0), 5)
    alpha = (soft.astype(float) / 255.0)[:, :, None]
    alpha = np.clip(alpha * 1.6, 0, 1)
    out = (out.astype(float) * alpha + img.astype(float) * (1 - alpha)).astype("uint8")
    return out


# ---------------------------------------------------------------- 验证

def ocr_region(img, box=None, langs="chi_sim+eng", scale=4, psm=7):
    """对指定区域放大后 OCR，返回识别文本。"""
    im = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    if box:
        pad = 6
        x0 = max(0, box["x"] - pad); y0 = max(0, box["y"] - pad)
        x1 = min(im.width, box["x"] + box["w"] + pad)
        y1 = min(im.height, box["y"] + box["h"] + pad)
        im = im.crop((x0, y0, x1, y1))
    im = im.convert("L").resize((im.width * scale, im.height * scale), Image.LANCZOS)
    tmp = os.path.join(tempfile.gettempdir(), "wm_ocr.png")
    im.save(tmp)
    try:
        txt = subprocess.run(["tesseract", tmp, "stdout", "-l", langs, "--psm", str(psm)],
                             capture_output=True, text=True, timeout=120).stdout.strip()
    except Exception:
        txt = ""
    return txt


def verify(out_img, boxes, ref=None, cur=None):
    """返回验证指标：区域内亮/暗异常像素、OCR 文本、与参考图的残留差分。"""
    g = to_gray(out_img).astype(float)
    h, w = g.shape
    report = {"residual_bright": 0, "residual_dark": 0, "ocr": "", "diff_vs_ref_max": None,
              "diff_vs_ref_px": None}
    for b in boxes:
        pad = 10
        sub = g[max(0, b["y"] - pad):min(h, b["y"] + b["h"] + pad),
                max(0, b["x"] - pad):min(w, b["x"] + b["w"] + pad)]
        if sub.size:
            report["residual_bright"] += int((sub > 215).sum())
            report["residual_dark"] += int((sub < 55).sum())
    if boxes:
        report["ocr"] = ocr_region(out_img, boxes[0])
    if ref is not None and cur is not None:
        a = to_gray(out_img).astype(float)
        b = to_gray(ref).astype(float)
        if a.shape != b.shape:
            b = cv2.resize(b, (a.shape[1], a.shape[0]))
        d = np.abs(a - b)
        roi = np.zeros(d.shape, bool)
        for bx in boxes:
            pad = 12
            roi[max(0, bx["y"] - pad):bx["y"] + bx["h"] + pad,
                max(0, bx["x"] - pad):bx["x"] + bx["w"] + pad] = True
        report["diff_vs_ref_max"] = float(d[roi].max()) if roi.any() else 0.0
        report["diff_vs_ref_px"] = int(((d > 20) & roi).sum())
    return report


# ---------------------------------------------------------------- 主流程

def main():
    ap = argparse.ArgumentParser(description="水印定位与像素级去除")
    ap.add_argument("-i", "--input", required=True, help="待处理图片（本地路径或 URL）")
    ap.add_argument("-o", "--output", default="", help="输出路径，默认 <input>_clean.png")
    ap.add_argument("--ref", default="", help="干净参考图（同一版式、无水印），用于差分定位")
    ap.add_argument("--corner", default="",
                    help="限定只在某角落找水印：br/bl/tr/tl/bottom-center（元宝、豆包水印固定 br）")
    ap.add_argument("--max-boxes", type=int, default=1, help="自动模式最多处理几处，默认 1")
    ap.add_argument("--region", default="", help="手动指定区域 x0,y0,x1,y1")
    ap.add_argument("--thresh", type=int, default=20, help="差分阈值，默认 20")
    ap.add_argument("--dilate", type=int, default=7, help="mask 膨胀核，默认 7")
    ap.add_argument("--retries", type=int, default=2, help="残留超标时自动加强修复次数，默认 2")
    ap.add_argument("--detect-only", action="store_true", help="只输出检测结果，不落盘")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出结果")
    args = ap.parse_args()

    cur = load_image(args.input)
    H, W = cur.shape[:2]
    info = {"input": args.input, "size": [W, H], "boxes": [], "method": None}

    # 1) 定位
    if args.region:
        x0, y0, x1, y1 = [int(v) for v in args.region.split(",")]
        boxes = [{"x": x0, "y": y0, "w": x1 - x0, "h": y1 - y0, "source": "manual"}]
        info["method"] = "manual"
    elif args.ref:
        ref = load_image(args.ref)
        boxes, _ = detect_by_diff(cur, ref, thr=args.thresh, corner=args.corner or None)
        info["method"] = "diff"
        info["ref"] = args.ref
    else:
        cands = detect_by_morph(cur)
        # 自动模式只取置信度最高的一处，避免误伤画面内容
        top = [c for c in cands if c["score"] >= 4.0][:max(1, args.max_boxes)]
        boxes = [{"x": c["x"], "y": c["y"], "w": c["w"], "h": c["h"],
                  "score": c["score"], "source": "morph",
                  "confident": c["score"] >= 4.0} for c in top]
        info["method"] = "morph"
        info["candidates"] = cands[:5]

    info["boxes"] = boxes
    if not boxes:
        info["error"] = "未检测到水印，请手动指定 --region 或提供 --ref"
        print(json.dumps(info, ensure_ascii=False, indent=2) if args.json else info["error"])
        return 2

    if args.detect_only:
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0

    # 2) 修复（必要时迭代加强）
    ref = load_image(args.ref) if args.ref else None
    mask = build_mask(cur.shape, boxes, dilate=args.dilate)
    out = inpaint_image(cur, mask)
    report = verify(out, boxes, ref=ref, cur=cur)
    tries = 0
    while tries < args.retries and _need_retry(report):
        tries += 1
        mask = build_mask(cur.shape, boxes, dilate=args.dilate + 4 * tries, iterations=3 + tries)
        out = inpaint_image(cur, mask)
        report = verify(out, boxes, ref=ref, cur=cur)
    info["repair_rounds"] = tries + 1
    info["verify"] = report

    # 3) 输出
    out_path = args.output or (os.path.splitext(args.input)[0] + "_clean.png")
    cv2.imwrite(out_path, out)
    info["output"] = out_path
    info["mask_pixels"] = int((mask > 0).sum())

    if args.json:
        print(json.dumps(info, ensure_ascii=False, indent=2))
    else:
        print("方法: %s" % info["method"])
        for b in boxes:
            print("  水印区域: x %d-%d, y %d-%d  (%dx%d, 来源 %s)"
                  % (b["x"], b["x"] + b["w"], b["y"], b["y"] + b["h"], b["w"], b["h"], b["source"]))
        print("修复像素: %d" % info["mask_pixels"])
        print("残留高亮像素: %d, 残留暗像素: %d" % (report["residual_bright"], report["residual_dark"]))
        if report["diff_vs_ref_max"] is not None:
            print("与参考图最大差分: %.1f, 超阈值像素: %d"
                  % (report["diff_vs_ref_max"], report["diff_vs_ref_px"]))
        print("区域 OCR: %r" % report["ocr"])
        print("输出: %s" % out_path)
    return 0


def _need_retry(report):
    if report["diff_vs_ref_px"] is not None:
        return report["diff_vs_ref_px"] > 50 or report["diff_vs_ref_max"] > 30
    return report["residual_bright"] > 300 or report["residual_dark"] > 300


if __name__ == "__main__":
    sys.exit(main())
