# -*- coding: utf-8 -*-
"""通用重复内容优化器：把「整行重复」改写成不重复的等价表达，而不是简单删除。

背景：番茄（及其他中文平台）发布校验『文章内容有大段落重复，请修改后提交』。
实测规则：
  · 任意一行（≥2字）重复 ≥3 次 → 拒收
  · ≥15字的长行重复 ≥2 次     → 拒收

处理顺序（每一处多余重复行依次尝试，全部要求"改写结果在本章内唯一"）：
  1) vary     —— 句式变换 / 语序变换 / 同义词替换，语义完全不变
  2) embed    —— 并入相邻句（消掉重复行，字数不减、语气衔接）
  3) condense —— 长段重复压缩为首个分句（完整内容已在首次出现处保留）
  4) drop     —— 以上都不适用时才删除（兜底）

并保证：
  · 处理后章内无任何违反平台规则的行（自检 0 违规）
  · 章节字数不低于 min_chars（不足时把已处理的行以改写形式补回）

设计为通用算法：句式库/同义词表均为中文网文常见表达，不含任何特定小说内容；
无法匹配通用句式时自动退化为"并入相邻句"或"删除"，不依赖书名词表。
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict

# ───────────────────────── 通用归一化（与平台判重口径一致） ─────────────────────────

_NON_WORD = re.compile(r"[\W_]+", re.UNICODE)


def pnorm(line: str) -> str:
    """平台判重口径的归一化：去掉标点/空白，只留字与数字（中英文通用）。"""
    return _NON_WORD.sub("", line or "")


# ───────────────────────── 通用同义词表（可按需扩充） ─────────────────────────

SYNONYMS: dict[str, list[str]] = {
    # 回想/复盘类
    "过了一遍": ["捋了一遍", "想了一遍", "盘了一遍", "走了一遍", "翻了一遍"],
    "在心里": ["在心底", "在心中", "在脑子里", "心里"],
    "又过了一遍": ["又捋了一遍", "重新过了一遍", "又想了一遍", "又盘了一遍"],
    # 决意/判断类
    "可他知道": ["可他明白", "但他清楚", "他清楚", "他明白", "他深知"],
    "可他没有": ["但他没有", "他没有", "可他并无"],
    "必须": ["得", "非得", "务必要"],
    "没有别的路": ["别无他路", "没有别的选择", "无路可退"],
    # 动作类
    "握紧": ["攥紧", "握得更紧", "紧紧握住"],
    "闭上眼": ["合上眼", "闭上眼睛", "眼帘一阖"],
    "点了点头": ["颔首", "点了下头", "微微点头"],
    "没有说话": ["没作声", "沉默着", "没有吭声"],
    "转身": ["回过身", "转过身", "扭过身"],
    "抬起眼": ["抬眼", "抬眸"],
    "笑了笑": ["笑了一下", "扯了扯嘴角", "淡淡一笑"],
    "深吸一口气": ["吸了口气", "深深吸了一口气", "喘了口气"],
    "没有说话，": ["沉默片刻，", "没有作声，"],
}

# 只做整体替换、不参与局部同义的连接词（保证语义不变）
_ADVERB_MOVE = re.compile(r"^(.{1,4})(在(?:心里|心底|心中|脑子里|暗地|心中暗想))[，,]\s*(.+)$")

# ───────────────────────── 通用句式模板（中文网文常见框架） ─────────────────────────
# 每条: (匹配正则, [变体模板])。模板里 {name} 取正则分组；{syn:词} 表示用同义词替换。
FRAME_RULES: list[tuple[re.Pattern, list[str]]] = [
    # 他/她 + 在X + 把Y + 又过了一遍
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<loc>在(?:心里|心底|心中|脑子里))[，,]?"
                r"把(?P<o>.{2,40}?)(?P<a>又|再|重新|从新)?(?P<v>过了一遍|捋了一遍|想了一遍|盘了一遍)"
                r"(?P<e>[。！？]?)$"),
     ["{s}{loc}，将{o}{a}{v}{e}",
      "{o}，{s}{loc}{a}{v}{e}",
      "{s}把{o}{loc}{a}重新过了一遍{e}",
      "{s}将{o}{loc}{a}{v}{e}"]),
    # 他/她 + 知道/清楚/明白 + 后半句
    (re.compile(r"^(?P<c>可|但|不过)?(?P<s>[他她它我]{1,2})?(?P<v>知道|清楚|明白)"
                r"(?P<o>[^。！？]{2,40})(?P<e>[。！？]?)$"),
     ["{c}{s}明白{o}{e}",
      "{c}{s}清楚{o}{e}",
      "{c}{s}深知{o}{e}"]),
    # 他/她 + 握紧/攥紧 + 宾语
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<v>握紧|攥紧|捏紧)(?P<o>[^。！？，,]{1,12})(?P<e>[。！？]?)$"),
     ["{s}将{o}紧紧握住{e}",
      "{o}，{s}握得更紧{e}",
      "{s}把{o}攥在手里{e}"]),
    # 他/她 + 闭上眼
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<v>闭上|合上)(?P<o>眼|眼睛)(?P<e>[。！？]?)$"),
     ["{s}合上眼{e}", "{s}闭上眼睛{e}", "{s}眼帘一阖{e}"]),
    # 他/她 + 转身 + 补语
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<v>转身|回过身|转过身)(?P<o>[^。！？]{0,20})(?P<e>[。！？]?)$"),
     ["{s}回过身{o}{e}", "{s}转过身{o}{e}", "{s}扭过身{o}{e}"]),
    # 他/她 + 点头
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<v>点了点头|点头)(?P<e>[。！？]?)$"),
     ["{s}颔首{e}", "{s}点了下头{e}", "{s}微微点头{e}"]),
    # 他/她 + 没有说话
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<v>没有说话|没说话|沉默不语)(?P<e>[。！？]?)$"),
     ["{s}没作声{e}", "{s}沉默着{e}", "{s}没有吭声{e}"]),
    # 他/她 + 抬起眼/抬起头 + 补语
    (re.compile(r"^(?P<s>[他她它我]{1,2})(?P<v>抬起眼|抬起头|抬眼)(?P<o>[^。！？]{0,24})(?P<e>[。！？]?)$"),
     ["{s}抬眼{o}{e}", "{s}抬眸{o}{e}", "{s}抬起头{o}{e}"]),
]

_SENT_SPLIT = re.compile(r"(?<=[。！？!?])")


# ───────────────────────── 候选生成 ─────────────────────────

def _apply_synonyms(line: str, idx: int) -> str | None:
    """按 idx 轮换选一个同义词做一次替换；无可替换词时返回 None。"""
    hits = [(w, syns) for w, syns in SYNONYMS.items() if w in line and syns]
    if not hits:
        return None
    # 从长词优先，保证替换粒度合理
    hits.sort(key=lambda x: -len(x[0]))
    word, syns = hits[idx % len(hits)]
    rep = syns[(idx // len(hits)) % len(syns)]
    if rep == word:
        return None
    return line.replace(word, rep, 1)


def _apply_frames(line: str) -> list[str]:
    out: list[str] = []
    for rx, tmpl in FRAME_RULES:
        m = rx.match(line.strip())
        if not m:
            continue
        gd = m.groupdict()
        for t in tmpl:
            try:
                cand = t.format(**{k: (v or "") for k, v in gd.items()})
            except (KeyError, IndexError):
                continue
            cand = re.sub(r"([，,]){2,}", r"\1", cand).strip()
            if cand and cand != line.strip():
                out.append(cand)
    # 通用：把"在X里，"状语后置（不改变语义）
    m = _ADVERB_MOVE.match(line.strip())
    if m:
        s, loc, rest = m.group(1), m.group(2), m.group(3)
        out.append(f"{s}把{rest}" if rest.startswith("把") else f"{s}{rest}，{loc}")
    return out


def _condense(line: str) -> str | None:
    """长行压缩：只保留第一个句子（完整内容已在首次出现处保留）。"""
    parts = [p for p in _SENT_SPLIT.split(line.strip()) if p.strip()]
    if len(parts) >= 2 and len(pnorm(parts[0])) >= 5:
        return parts[0].strip()
    return None


_SPLIT_AT = re.compile(r"[，,；;]")


def _split_candidates(line: str, min_part: int = 3) -> list[list[str]]:
    """通用拆分：按逗号把一行拆成两行（一字不改、语义不变，只改分行）。

    用于"改不了措辞、又不想丢字"的重复行（如动作短句的打点重复）。
    """
    src = line.strip()
    out: list[list[str]] = []
    for m in _SPLIT_AT.finditer(src):
        a, b = src[:m.start()].strip(), src[m.end():].strip()
        if not a or not b or not b.endswith(("。", "！", "？")):
            b = b.rstrip("，,；;") + "。"
        if not a.endswith(("。", "！", "？")):
            a += "。"
        if len(pnorm(a)) >= min_part and len(pnorm(b)) >= min_part:
            out.append([a, b])
    return out


# ───────────────────────── 主流程 ─────────────────────────

def optimize_repeats(text: str, *, min_len: int = 15, keep_long: int = 1,
                     keep_short: int = 2, min_chars: int = 1000,
                     max_echo: int = 2, min_gap: int = 2,
                     mode: str = "vary", log=None) -> tuple[str, dict]:
    """处理章内重复行：保留必要重复 + 中段改写回响，其余去掉。

    策略（mode="vary"，默认）：
      1) 紧邻同键行（生成器"复读"）→ 去掉，连着说两遍最伤阅读
      2) 原文保留：长行 1 处（keep_long）、短行首末 2 处（keep_short）
      3) 中段留 1 处"改写回响"：长行压缩为首个分句并换措辞，短行整体换措辞
         （与所有保留行至少隔 1 行，读起来是呼应而不是复读）
      4) 其余重复行去掉
    另：处理后不足 min_chars 时，把去掉的行以改写形式补回（保证过平台字数下限）。
    mode="drop" 为旧的纯删除策略（保留给需要极简输出的场景）。

    返回 (新文本, 统计)。统计含 actions 明细与 chars_before/after/violations。
    """
    _log = log or (lambda *_: None)
    if min_len <= 0 or not text:
        return text, {"actions": {}, "chars_before": len(pnorm(text)),
                      "chars_after": len(pnorm(text)), "violations": 0}

    lines = text.split("\n")
    keys = [pnorm(l) for l in lines]
    groups: dict[str, list[int]] = defaultdict(list)
    for i, k in enumerate(keys):
        if len(k) >= 2:
            groups[k].append(i)

    used = Counter(keys)                      # 章内归一化计数（用于唯一性校验）
    drop_idx: set[int] = set()
    repl: dict[int, str] = {}
    actions = Counter()

    def _unique(cand: str) -> bool:
        ck = pnorm(cand)
        return len(ck) >= 2 and used[ck] == 0

    def _take(i: int, cand: str, act: str) -> bool:
        if not _unique(cand):
            return False
        used[pnorm(lines[i])] -= 1            # 原行下线
        repl[i] = cand
        used[pnorm(cand)] += 1                # 新行上线
        actions[act] += 1
        return True

    def _take_split(i: int, parts: list[str]) -> bool:
        """用两个片段替换一行（拆分，一字不改）。"""
        kk = [pnorm(p) for p in parts]
        if any(len(k) < 2 or used[k] > 0 for k in kk) or len(set(kk)) != len(kk):
            return False
        used[pnorm(lines[i])] -= 1
        repl[i] = "\n".join(parts)
        for k in kk:
            used[k] += 1
        actions["split"] += 1
        return True

    def _cands(src: str) -> list[str]:
        out = _apply_frames(src)
        out += [c for c in (_apply_synonyms(src, k) for k in range(len(SYNONYMS))) if c]
        return out

    # ── 逐组处理：原文保留 + 中段留一个远距离的改写回响，其余重复去掉 ──
    def _adjacent_same(i: int) -> bool:
        """本行上下（跳过空行）是否有同键行——生成器"复读"痕迹，最该去掉。"""
        k = keys[i]
        for step in (-1, 1):
            j = i + step
            while 0 <= j < len(lines) and not lines[j].strip():
                j += step
            if 0 <= j < len(lines) and keys[j] == k:
                return True
        return False

    # ── 阶段1：定保留行；复读行直接去掉；规划"回响"位（全局间距控制，避免扎堆） ──
    echo_of: dict[int, str] = {}
    plan: list[tuple[bool, list[int], list[int]]] = []      # (是否长行, 保留, 待处理)
    for key, idxs in groups.items():
        is_long = len(key) >= min_len
        quota = keep_long if is_long else keep_short
        if len(idxs) > quota:
            survivors = [idxs[0]] if quota == 1 else [idxs[0], idxs[-1]]
        else:
            survivors = list(idxs)             # 未超限：都留着（复读行另处理）
        victims = [i for i in idxs if i not in survivors]
        for i in victims:
            if _adjacent_same(i):              # 连着说两遍：最刺眼的生成器故障
                drop_idx.add(i)
                actions["drop"] += 1
        plan.append((is_long, survivors, victims))

    MAX_ECHO = max(0, max_echo)                # 每章最多留几处回响（防注水）
    MIN_GAP = max(1, min_gap)                  # 回响与保留行/其它回响的最小"排版距离"
    if mode != "drop" and MAX_ECHO > 0:
        all_victims = {i for _, _, vs in plan for i in vs}

        def _final_pos() -> dict[int, int]:
            """按"删除+回响"后的最终版面给每行编号（未保留的行与其前一行同位）。"""
            pos: dict[int, int] = {}
            n = 0
            for i in range(len(lines)):
                if i not in drop_idx and (i not in all_victims or i in echo_of):
                    n += 1
                pos[i] = n
            return pos

        def _kept(i: int) -> bool:
            return i not in drop_idx and (i not in all_victims or i in echo_of)

        def _sandwiched(i: int) -> bool:
            """前后最近的保留行若是同一句，则夹在中间读起来还是复读。"""
            prev_k = nxt_k = ""
            for j in range(i - 1, -1, -1):
                if _kept(j):
                    prev_k = keys[j]
                    break
            for j in range(i + 1, len(lines)):
                if _kept(j):
                    nxt_k = keys[j]
                    break
            return bool(prev_k) and prev_k == nxt_k

        for is_long, survivors, victims in sorted(plan, key=lambda t: t[1][0]):
            if len(echo_of) >= MAX_ECHO:
                break
            pool = [i for i in victims if i not in drop_idx]
            if not pool:
                continue
            center = (survivors[0] + survivors[-1]) / 2
            for cand in sorted(pool, key=lambda i: abs(i - center)):
                pos = _final_pos()
                # 与本组保留行保持距离（防"夹心"复读）
                if not all(abs(pos[cand] - pos[s]) >= MIN_GAP for s in survivors):
                    continue
                # 与其它回响保持距离（防扎堆注水）
                if not all(abs(pos[cand] - pos[e]) >= MIN_GAP for e in echo_of):
                    continue
                if _sandwiched(cand):
                    continue
                echo_of[cand] = "condense" if is_long else "vary"
                break

    # ── 阶段2：执行（回响改写 / 其余删除） ──
    for is_long, survivors, victims in plan:
        for i in victims:
            if i in drop_idx:
                continue
            if mode == "drop" or (i not in echo_of and mode != "rewrite"):
                drop_idx.add(i)
                actions["drop"] += 1
                continue
            # 改写：长行压缩为首句（完整内容已在首次出现处保留）或整体换措辞
            cands: list[str] = []
            if is_long:
                c = _condense(lines[i])
                if c:
                    cands.append(c)
                    cands += _cands(c)         # 压缩后若仍重名则再换措辞
            cands += _cands(lines[i])
            if mode == "rewrite":              # 保字数模式：改写优先，尽量不删
                cands += [p for parts in _split_candidates(lines[i]) for p in parts] + \
                         [c for c in (_apply_synonyms(lines[i], k) for k in range(len(SYNONYMS) * 3))
                          if c]
            for c in cands:
                if _take(i, c, "condense" if is_long else "vary"):
                    break
            else:
                for parts in _split_candidates(lines[i]):   # 改不了措辞就改分行（不丢字）
                    if _take_split(i, parts):
                        break
                else:
                    drop_idx.add(i)
                    actions["drop"] += 1

    def _assemble() -> str:
        """按原文行序拼回：去掉删除行、写入替换行，保留原有空行结构。"""
        parts = [repl.get(i, ln) for i, ln in enumerate(lines) if i not in drop_idx]
        return re.sub(r"\n{3,}", "\n\n", "\n".join(parts))

    def _destutter(txt: str) -> tuple[str, int]:
        """版面复读清理：删除行之后，版面上紧邻的同句（最刺眼的小瑕疵）再去一层。"""
        out: list[str] = []
        last_key = ""
        n = 0
        for ln in txt.split("\n"):
            k = pnorm(ln)
            if k and k == last_key:
                n += 1
                actions["destutter"] += 1
                continue
            out.append(ln)
            last_key = k
        return "\n".join(out), n

    new_text = _assemble()
    for _ in range(3):                         # 收敛：去掉一层后可能又出现新的紧邻同句
        new_text, _n = _destutter(new_text)
        if not _n:
            break

    # ── 字数下限保障：不足则把已丢弃的行以改写形式补回（避开复读位） ──
    if min_chars > 0 and len(pnorm(new_text)) < min_chars:
        for key, idxs in groups.items():
            if len(pnorm(new_text)) >= min_chars:
                break
            for i in idxs:
                if i not in drop_idx or _adjacent_same(i):
                    continue
                for c in _cands(lines[i]):
                    if _unique(c):
                        used[pnorm(c)] += 1
                        repl[i] = c
                        drop_idx.discard(i)
                        actions["restore"] += 1
                        new_text = _assemble()
                        break
        if len(pnorm(new_text)) < min_chars:
            _log(f"  ⚠ 去重后仍不足 {min_chars} 字（{len(pnorm(new_text))} 字），需人工补充")

    stats = {
        "actions": dict(actions),
        "chars_before": len(pnorm(text)),
        "chars_after": len(pnorm(new_text)),
        "violations": count_violations(new_text, min_len),
    }
    return new_text, stats




def count_violations(text: str, min_len: int = 15) -> int:
    """自检：返回仍违反平台规则的重复行数（长行≥2次 / 短行≥3次）。"""
    cnt = Counter(k for k in (pnorm(l) for l in text.split("\n")) if len(k) >= 2)
    return sum(1 for k, n in cnt.items()
               if (len(k) >= min_len and n >= 2) or (len(k) < min_len and n >= 3))


__all__ = ["optimize_repeats", "count_violations", "pnorm", "SYNONYMS", "FRAME_RULES"]
