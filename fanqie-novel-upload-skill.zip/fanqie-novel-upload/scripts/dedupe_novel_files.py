# -*- coding: utf-8 -*-
"""章节文件重复内容优化 CLI（独立运行，只依赖同目录的 rewrite.py）

用法:
  python dedupe_novel_files.py "章节目录" [--dry-run] [--min-len 15] [--min-chars 1000]
                               [--mode vary|rewrite|drop]

行为:
  · 扫描目录下所有 .txt 章节，调用 rewrite.optimize_repeats 处理重复内容
  · 原文件备份到目录内 .dup_backup/（点前缀，上传解析自动忽略）
  · 已存在备份时**以备份为输入重建**——反复运行结果一致，不会二次删减
"""
from __future__ import annotations

import argparse
import io
import os
import shutil
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from rewrite import optimize_repeats  # noqa: E402

BACKUP_DIRNAME = ".dup_backup"


def process_folder(folder: str, min_len: int = 15, min_chars: int = 1000,
                   mode: str = "vary", dry_run: bool = False) -> dict:
    folder = os.path.abspath(folder)
    stats = {"scanned": 0, "modified": 0, "chars_before": 0, "chars_after": 0,
             "actions": {}, "violations": 0, "too_short": []}
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fn in sorted(files):
            if not fn.lower().endswith(".txt"):
                continue
            p = os.path.join(root, fn)
            rel = os.path.relpath(p, folder)
            bp = os.path.join(folder, BACKUP_DIRNAME, rel)
            stats["scanned"] += 1
            src = bp if os.path.exists(bp) else p      # 有备份就以备份为输入重建
            raw = io.open(src, "r", encoding="utf-8", errors="ignore").read()
            new_text, st = optimize_repeats(raw, min_len=min_len, min_chars=min_chars,
                                            mode=mode)
            for k, v in st["actions"].items():
                stats["actions"][k] = stats["actions"].get(k, 0) + v
            stats["chars_before"] += st["chars_before"]
            stats["chars_after"] += st["chars_after"]
            stats["violations"] += st["violations"]
            if st["chars_after"] < min_chars:
                stats["too_short"].append((rel, st["chars_after"]))
            if new_text == raw:
                continue
            stats["modified"] += 1
            print(f"  {'[演练] ' if dry_run else ''}{rel}: {st['chars_before']}→{st['chars_after']} 字 "
                  f"{st['actions'] if st['actions'] else ''}")
            if not dry_run:
                os.makedirs(os.path.dirname(bp), exist_ok=True)
                if not os.path.exists(bp):             # 不覆盖首次备份
                    shutil.copy2(p, bp)
                with io.open(p, "w", encoding="utf-8", newline="\n") as f:
                    f.write(new_text)
    return stats


def main():
    ap = argparse.ArgumentParser(description="章节文件重复内容优化工具")
    ap.add_argument("folder", help="章节目录")
    ap.add_argument("--min-len", type=int, default=15,
                    help="长行判定阈值（默认15字：≥此长度重复2次即处理）")
    ap.add_argument("--min-chars", type=int, default=1000,
                    help="清理后正文字数下限（默认1000，不足自动以改写补回）")
    ap.add_argument("--mode", choices=["vary", "rewrite", "drop"], default="vary",
                    help="vary=改写+压缩+去多余重复(默认)；rewrite=尽量保留原文；drop=纯删除")
    ap.add_argument("--dry-run", action="store_true", help="只报告不修改")
    args = ap.parse_args()

    folder = os.path.abspath(args.folder)
    if not os.path.isdir(folder):
        print(f"✗ 目录不存在: {folder}")
        return 1
    print(f"扫描: {folder}  (阈值 {args.min_len} 字，字数下限 {args.min_chars}，模式 {args.mode}，"
          f"{'演练' if args.dry_run else '正式优化'})")
    stats = process_folder(folder, args.min_len, args.min_chars, args.mode, args.dry_run)
    print()
    print(f"完成: 扫描 {stats['scanned']} 个文件 / 改动 {stats['modified']} 个 | "
          f"字数 {stats['chars_before']} → {stats['chars_after']} "
          f"(保留 {100 * stats['chars_after'] / max(1, stats['chars_before']):.1f}%)")
    print(f"      处理明细: {stats['actions']} | 平台规则违规残留: {stats['violations']}")
    if stats["too_short"]:
        print(f"      ⚠ 不足 {args.min_chars} 字的章节 {len(stats['too_short'])} 个（需人工补充）: "
              f"{stats['too_short'][:5]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
