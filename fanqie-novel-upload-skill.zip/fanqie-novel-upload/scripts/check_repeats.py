# -*- coding: utf-8 -*-
"""重复内容自检：报告目录下每个章节文件的"平台判重违规"与字数下限情况。

用法:
  python check_repeats.py "章节目录" [--min-len 15] [--min-chars 1000]

退出码: 0 = 全部通过；1 = 存在问题（违规行 / 字数不足）
"""
from __future__ import annotations

import argparse
import os
import sys
from collections import Counter

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from rewrite import pnorm  # noqa: E402


def check_text(text: str, min_len: int = 15) -> list[tuple[str, int]]:
    """返回违规行 [(去标点后的行, 出现次数)]：长行≥2次 / 短行≥3次。"""
    cnt = Counter(k for k in (pnorm(l) for l in text.split("\n")) if len(k) >= 2)
    return [(k, n) for k, n in cnt.items()
            if (len(k) >= min_len and n >= 2) or (len(k) < min_len and n >= 3)]


def main() -> int:
    ap = argparse.ArgumentParser(description="章节重复内容自检")
    ap.add_argument("folder", help="章节目录")
    ap.add_argument("--min-len", type=int, default=15, help="长行阈值（默认15字）")
    ap.add_argument("--min-chars", type=int, default=1000, help="正文字数下限（去标点口径）")
    args = ap.parse_args()

    folder = os.path.abspath(args.folder)
    if not os.path.isdir(folder):
        print(f"✗ 目录不存在: {folder}")
        return 1

    files = 0
    bad_files = 0
    short_files = []
    for root, dirs, names in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")]   # 跳过 .dup_backup 等
        for fn in sorted(names):
            if not fn.lower().endswith(".txt"):
                continue
            p = os.path.join(root, fn)
            text = open(p, encoding="utf-8", errors="ignore").read()
            files += 1
            viol = check_text(text, args.min_len)
            n_chars = len(pnorm(text))
            if viol:
                bad_files += 1
                print(f"✗ {os.path.relpath(p, folder)}: {len(viol)} 处违规")
                for k, n in sorted(viol, key=lambda x: -x[1])[:3]:
                    print(f"     ×{n} ({len(k)}字) {k[:40]}")
            if n_chars < args.min_chars:
                short_files.append((os.path.relpath(p, folder), n_chars))

    print()
    print(f"检查 {files} 个文件 | 判重违规 {bad_files} 个 | 不足 {args.min_chars} 字 {len(short_files)} 个")
    if short_files:
        for rel, n in short_files[:5]:
            print(f"   ⚠ {rel}: {n} 字")
    ok = not bad_files and not short_files
    print("结论: " + ("全部通过 ✓" if ok else "存在问题，需处理 ✗"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
