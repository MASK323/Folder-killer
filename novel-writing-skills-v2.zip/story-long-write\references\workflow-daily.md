# workflow-daily.md：日更续写工作流

本文件为"日更续写"场景的完整指引。SKILL.md 路由到本文件后，按以下流程执行。

> **日更准备步骤**：每章写作前 4 步——状态筛选 + 题材正文提示卡召回 + 文风召回 + 意图确认，嵌入 Step 2 逐章循环。
>
> 写前资料清单、对标书路径查找、题材正文提示卡、自定义文风模式、文风缺失 fail-fast、模块/节奏缺失停止、权威冲突规则、无对标项目处理，一律按 [project-files.md](project-files.md) 的「缺失文件处理」「对标分析权威优先级」和 [benchmark-recall.md](benchmark-recall.md) 的写前准备 (a)-(g) 执行；本文件不另立一套。读者契约、主角代理权、期待债、终局储备参 `reader-contract-and-progression.md`。
>
> **多本对标书**：从 `设定/题材定位.md` 读 `主对标书` 字段；字段指向当前作品时按缺失处理（老项目可能把本书自身登记成了主对标）。缺失时用 `对标/` 下字典序第一本并提示用户补字段——先按当前项目目录名、`.active-book` 和 `设定/题材定位.md` 中的本书信息识别当前作品，排除同名或来源指向当前正文的 `对标/{当前书}/`；排除后为空则按无对标处理。

---

## 适用条件

- 项目已有 `正文/` 和 `追踪/` 目录
- 用户明确说"日更""续写""继续写"，或明确指定"写第 N-M 章"
- 目标：每次会话写 2-3 章（4000-9000 字）

> **裸调用不进日更**：如果用户只是触发 `/story-long-write` / `$story-long-write`，没有说"日更/续写/继续写/写第N章/只写1章/逐章确认"，不得进入本 workflow。回到 `SKILL.md` 的"裸调用与停靠点"，只展示当前进度与可选命令，避免重启会话后自动写 3 章。

---

## Step 1：快速上下文加载

**可选：使用 story-explorer agent 批量加载上下文**。如果项目已部署 story-explorer agent（检查 `.claude/agents/story-explorer.md` 是否存在），可以用 `Agent(subagent_type: "story-explorer", prompt: "项目目录：{dir}\n查询类型：context_load\n查询参数：准备写第 {N} 章\n追踪状态：last_committed_chapter={上一步 check 的值}，state_revision={上一步 check 的值}")` 执行 `context_load` 查询，一次获取全部写作上下文。spawn 返回后直接使用其 results，跳过下方手动加载步骤。如果 agent 不可用或返回不完整，回退到下方手动加载。

手动加载（默认方式）：

| 序号 | 文件 | 用途 | 如果不存在 |
|------|------|------|-----------|
| 1 | `tracking_commit.py check` | 校验唯一结构化 state 与全部派生视图，并取得最后提交章和修订号；不把完整 state 加入 prompt | state 缺失且新书尚无正文时执行初始化；已有正文则停止并要求由 `story-import` 重新导入为标准项目 |
| 2 | `追踪/上下文.md` | 续写状态卡（≤12KB，固定 7 栏，每章整份读） | 不手写；由初始化/逐章事务生成 |
| 3 | `大纲/细纲_第{N}章.md` | 本章写作计划 | **必须先补建**，不允许跳过 |
| 4 | 卷纲（**取段器读，不整读**：`outline_view.py --unit {单元ID} --stage write`，见 SKILL.md「卷纲不整读」） | 卷契约、全卷常任裁定、当前剧情单元、终局储备与未来揭示计划 | 缺必需字段时先补齐；锁定卷纲绝不自动修改；脚本 exit 1 不得改用整读绕过 |
| 5 | `设定/角色/{角色名}.md` | 本章涉及角色的静态原始人设 | 只为核心复用角色按 Phase 3 规则补建 |
| 6 | `追踪/角色状态/{角色名}.md` | 久别核心角色的派生当前快照；只按细纲涉及角色加载 | 缺失即视为派生视图损坏：先运行 `tracking_commit.py check`，再重跑产生当前状态的完整事务；已有正文却无 state 时重新 `story-import` |

`追踪/伏笔.md`、`追踪/时间线/`、`追踪/逐章记录/` 默认不整份读取。续写状态卡没有某个旧信息时，才按「旧信息查找步骤」定点查询。

**按需加载**：需要期待感、爽点或信息差约束时，加载 `references/plot-emotion-system.md`、`references/plot-core-methods.md` 或当前 `references/genre-prose-cards/` 题材卡。默认不全量加载。

### 续写状态卡与追踪事务

`追踪/上下文.md` 不是历史档案，而是当前语义检查点中的续写状态卡；顶层只能有以下 7 个栏目：`当前位置 / 长期约束 / 核心角色状态 / 活跃伏笔 / 近三章速记 / 下一章承诺 / 连贯性风险`。目标 8192 字节，硬上限 12288 字节。文风每章从 `设定/文风.md` / 对标文风读取；质量计数、普通待办、文件行数索引、参照章使用记录、去 AI 味统计都不进入续写状态卡。

所有追踪文件的 schema、事务 JSON、初始化和失败修复统一见 [tracking-transaction.md](tracking-transaction.md)。每章只向工具提交一次结构化事务，由 `scripts/tracking_commit.py` 确定性生成逐章增量、角色快照、伏笔当前视图、作者/读者时间线和续写状态卡；主会话和子 agent 都不得分别直接改这些最终文件。

**首次初始化**：

1. `_tracking-state.json` 不存在且项目尚无正文：先完整读取 [tracking-initialization.md](tracking-initialization.md)，构造 `last_chapter=0` 的初始化事务，执行 `tracking_commit.py init`。
2. `_tracking-state.json` 不存在但项目已有正文：停止日更。该目录停在旧追踪结构上，走 `/story-import` 的「旧追踪项目迁移」重建 `追踪/`——**不用重跑全书拆解**，只按最后完整章号和现有追踪文件构造初始化事务。本 workflow 自己不解析旧追踪结构、不推测状态。`init` 会把旧结构按原样整体移入 `追踪/_旧追踪存档/` 再建当前协议——旧内容不删除也不参与解析。
3. `tracking_commit.py check` 报告派生视图与 state 不一致：重新提交该章的 `mode=revision` 事务让工具整份重建（`expected_state_revision` 取 `追踪/_tracking-state.json` 的 `state_revision` 字段——`check` 失败时只往 stderr 打 ERROR，不输出 JSON）；不得手改 Markdown 或继续写下一章。手写出的逐章记录会让同章 append 永久报 `chapter delta N already exists with different content`，删掉那个手写文件后重跑原事务即可。

**长期约束溢出**：工具最多接受 6 条。出现第 7 条时，在提交事务前先合并语义重叠项或请用户裁定取舍；不得自动删除旧约束，也不得把待办塞进派生视图。

**退役必须显式声明**：`context.long_term_constraints` 和 `context.continuity_risks` 每章整份提交，因此每次都要把仍然成立的条目原样带上。凡是上一版有、本次不再提交的条目，必须逐条写进 `delta.retired_context_items`；漏写会被工具在任何写入前拒绝，不会被当成删除。不再复用的核心角色同理写进 `delta.retired_characters`；角色本章阵亡/退场时照常写 `character_changes`，不必再交一份马上要删的快照。两类退役都只能在 `mode=append` 提交——修订事务的记录属于被改写的旧章，写在那里会谎报退役章节；回炉必须原样重交当前全部上下文条目。两类退役都会留档在本章逐章记录，事后可回查。

**与项目 rules 的关系**：永久生效的设定裁定进入事务 `context.long_term_constraints`；短期强承诺进入 `delta.next_chapter_commitments`；已完成或只影响本章的过程决策不进续写状态卡。

> **确定下一章编号 N 与状态修订号**：执行 `tracking_commit.py check`，从其紧凑 JSON 输出取 `last_committed_chapter + 1` 与 `state_revision`，同时核对 `上下文.md` 的当前位置。逐章事务必须把该修订号写进 `expected_state_revision`；若提交前状态已经变化，工具会在任何写入前拒绝旧事务，此时重新读取当前状态并重构。不要把会随历史增长的完整 state 读进 prompt；章号不一致时修复，不扫描正文猜测编号。

确定本轮写作范围后直接进入 Step 2，不做"是否继续"式确认。K 默认 2-3 章；用户明确说"只写1章"/"日更3章"/"逐章确认"时按用户要求调整。用户给出 N>3 时，本轮只写前 3 章并在 Step 4 进度摘要提示"剩余章节下轮继续"。仅在章节号冲突、细纲缺失、请求范围超过已有细纲、用户要求会改变大纲/追踪，或存在其他会导致写错的阻塞信息时暂停确认。

---

## Step 2：串行批量写作

一次加载多章细纲，但**必须在主会话内串行逐章写作**：不得把多章同时交给多个子代理并发写。长篇章节依赖上一章正文和追踪文件，并发会导致上下文断裂、追踪覆盖和标题去重失效。

**批量 continuation 规则**：进入本 Step 后，"继续"/"续写"/"日更"只表示继续当前日更批量流程。不得把这些词解释为跳过「状态筛选」或「对标模块/节奏/题材卡/文风召回」的直接正文续写；也不得在每章之间重复询问是否继续，除非用户明确要求逐章确认或出现阻塞。到达本轮 K（最多 3 章）后必须进入 Step 3/4 收尾并停止，不能因为仍有后续细纲就继续写下一批。

1. **读取写作计划**：写作计划按 **卷契约 → 当前剧情单元 → 章节细纲** 的顺序确定；已写内容仍以正文与 `追踪/` 文件为准。先按 SKILL.md「卷纲不整读」跑 `outline_view.py --unit {单元ID} --stage write {卷纲路径}` 取卷契约、全卷常任裁定、当前剧情单元（单元ID/位置）、单元情绪引擎、本卷主推线/战果与终局底牌边界（单元ID 从本批首章细纲「单元ID/位置」取），再加载本次要写的 2-3 章细纲。卷纲或细纲缺少当前协议的必需字段时按既有流程先补齐，未知字段写 `[待补充]`；已锁定卷纲不得自动改动。细纲读取阶段位置、结构公式、禁止提前释放、内容概括、情节安排、人物关系/出场顺序、情节细化的语义义务/执行边界及结尾钩子，不读取或心算逐点字数预算。只有真正影响后续连续性的结果才进入本章事务。
   - **批次定位与阶段约束**：写本批前先从 `大纲/大纲.md`、上一步取段器的卷纲输出（不再重读卷纲）和本批细纲提取：当前章节区间属于哪个阶段、本批推进目标、本批可释放的信息、本批严禁提前释放的信息、章尾钩子不能越过的边界。必须按终局储备确认本批主推线与战果，别动用本阶段还不该解锁的终局底牌（多线齐涨的战果允许）；行动成本可无，不硬造代价。未来揭示计划留在大纲，不写入时间线事实；只有下一章必须消费的边界才进 `## 下一章承诺`。
   - **阶段进度自检**：每批写完或补完细纲后检查是否超前、拖慢或偏离阶段节奏；若偏离，把下一章必须执行的补偿动作放入事务 `next_chapter_commitments`，跨多章风险放入 `continuity_risks`；不得通过提前泄露后期信息强行提速。
2. **逐章执行**：每章按 [workflow-chapter.md](workflow-chapter.md) 的「单章写作流程」步骤 1-13 完整走一遍（写前准备、正文执行、字数验证、钩子/爽点检查、元信息与禁用词扫描、追踪事务）。批量模式下再叠加下列日更专属动作：
   - **上一章欠账检查**：写本章正文前，确认上一章正文无未清 blocking 毒句式欠账（写前 hook 会自动拦；hook 不可用时对上一章跑 `node scripts/check-ai-patterns.js --check --fail-on=blocking`）；有欠账先清完再写本章，除非上一章标了 `<!-- 去味:跳过 -->`（用户显式豁免）
   - **状态来源纪律**：不要为取状态/章号把完整 `_tracking-state.json` 加载进 prompt；缺失内容按下方「旧信息查找步骤」定点查询，不得用未标明来源的聊天记忆替代，也不得为了方便通读所有逐章记录。
   - **久别角色交叉检查**：本章细纲列出的核心复用角色若不在 `## 核心角色状态`，直接读取小文件 `追踪/角色状态/{名}.md`；不存在即视为当前检查点损坏，运行 `tracking_commit.py check` 并通过完整事务修复，不能临时扫描增量后手写替代。`设定/角色/{名}.md` 只有静态原始人设，不能替代动态快照。角色重新活跃后，把名字放进本章事务 `context.active_character_names`，由工具更新续写状态卡。
   - **story-explorer 召回的 gaps 分支**（用 `benchmark_style_load` query_type 一次拿到 `{style_profile_path, style_profile_summary, selected_emotion_module, rhythm_reference, module_source_path, rhythm_source_path, matched_chapter_K, matched_chapter_techniques, anchor_excerpts, gaps}` 后按此分流）：
     - 若 `gaps.no_benchmark: true` → `custom_style` 为真则进入「自定义文风模式」（用 `设定/文风.md` 写作；无对标可召回，情绪 / 节奏目标改从本书细纲「目标情绪」、卷纲、`设定/题材定位.md` 等内部材料取，`selected_emotion_module` / `rhythm_reference` 记为「无」，不声称从对标召回）；否则跳过文风召回，在「意图确认」标记"无对标参考"
     - 若 `gaps.missing_primary_contract: true` → 停止本章准备，按 `repair_action` 提示重跑 `/story-long-analyze` Stage 3+ 或重新 `/story-import`；不得进入 narrative-writer（情绪 / 节奏轴独立于文风轴，**自定义文风模式不豁免此停止**——补 `剧情/情绪模块.md` / `剧情/节奏.md`，而非写 `设定/文风.md`）
     - 若 `gaps.benchmark_book_missing: true` → 停止，核对 `expected_path` 与 题材定位.md 登记名（逐字一致）后重查；不得换书
     - 若 `gaps.conflict` 或 `gaps.module_rhythm_conflict: true` → 意图确认必须说明冲突并按 `剧情/情绪模块.md` / `剧情/节奏.md` 的权威优先级执行；不得让 `文风.md` 覆盖情绪/节奏目标
     - 若 `gaps.profile_missing: true` → `custom_style` 为真则进入自定义文风模式继续；否则按上文 fail-fast 流程停止
     - 若 `gaps.profile_degenerate: true`（对标文风不可用） → `custom_style` 为真则用 `设定/文风.md` 写作；否则跳过文风、回到默认 Gates 写作
     - 若 `gaps.tone_match_failed: true` → 仅用整书文风写作，不喂 matched_chapter
     - 否则原样传给 `style_profile_path`、`style_profile_summary`、`selected_emotion_module`、`rhythm_reference`、`module_source_path`、`rhythm_source_path`、`matched_chapter_K`、`matched_chapter_techniques`、`anchor_excerpts` 和 `genre_prose_card` 给 Step 2 末尾的 narrative-writer spawn prompt；其中 `selected_emotion_module` 必须进入情绪目标，`rhythm_reference` 必须进入节奏/爆发安排，`genre_prose_card` 必须进入题材取舍，`matched_chapter_techniques` 必须进入「文风召回指令」。写前准备记录必须保留 `gaps` 原值，尤其 `gaps.module_missing`、`gaps.rhythm_missing`、`gaps.conflict`、`gaps.matched_deep_dive_missing`；若 `matched_deep_dive_missing` 为 true，文风召回指令中明确写“同章深度拆解缺失，已回退黄金三章/文风技巧”，不得在后续报告中反转为 false
     - **无 story-explorer 时直接执行**：主会话按 workflow-chapter.md 写前准备 (a)-(f) 手动依次召回情绪模块、节奏、题材卡、文风与匹配章 K；模块或节奏文件缺失时设置 `missing_primary_contract` 并停止修复
   - **写后清零不拖到批末**：写后 hook 推回的毒句式命中当轮清零，不得攒到 Step 3。
   - 每章写完后**立即提交一次追踪事务**：
     1. 从刚落盘的正文、细纲和上一版续写状态卡提取 `result / character_changes / foreshadow_changes / timeline_events / constraints / next_chapter_commitments`。只记录会影响未来章节的变化；过程日志、质检计数、参照章和去 AI 味统计全部排除。
     2. 需要长期复用的核心角色，把完整动态快照放进 `character_snapshots`，并在 `character_changes` 写对应变化；一次性路人只写变化、不交快照。已有动态快照的核心角色再次变化时必须提交新快照。静态人设继续以 `设定/角色/{名}.md` 为准。
     3. `context.long_term_constraints`、当前卷/故事时间/场景、活跃核心角色名、连贯性风险提交当前完整值；活跃伏笔、近三章速记和下一章承诺由工具从当前视图/本章增量派生，不重复手填。
     4. 运行 `storyctl.py chapter check`，取 `state_revision` 写入无 `wordcount` 的事务。带内 + quality pass → `chapter commit`；`under` 不补，`over` 按 workflow-chapter 步骤 8 净删一次并复检；仍带外走该步骤三动作。提交会重读、重数、重跑 quality；成功后删临时 JSON，tracking 提交后才继续。
     5. 失败时 `_tracking-state.json` 尚未推进；保留临时 JSON，修正写入环境后重跑同一 `commit`。不得另写下一章、不得手工补派生视图、不得忽略返回码。

     `追踪/逐章记录/第NNN章.md` 由工具按 5 类变化生成，目标 ≤1536 字节、硬上限 3072 字节。它不是正文摘要大全，更不保存写作过程。`伏笔.md` 每个 ID 只有一行当前状态；角色状态按核心角色拆文件；时间线的客观事实和读者认知只在同一事件登记中维护，再派生作者/读者两个视图。

     状态更新仍由主会话负责。narrative-writer 只写正文并回报必要的写作结果，不直接写 `追踪/`；主会话也不绕过事务工具直接修改最终追踪文件。
   - **质检提示**（可选）：本章写作完成。如需一致性检查，运行 `/story-review lean`。批量写作模式跳过此步骤，全部写完后再统一审查。
3. **不中断但不并发**：tracking 已提交即进下一章（除非用户要求确认）；`under` 或一次压缩后仍带外则展示证据/动作，不静默推进。下一章先读上一章正文与追踪更新。

**资料研究（按需）**：如果写作中遇到需要查证的外部事实（历史年代、地理方位、职业细节等），暂停写作，spawn `story-researcher` agent 搜索并输出到 `参考资料/` 目录。研究完成后再继续写作。

### 旧信息查找步骤

状态摘要里没有、但本章确实需要的旧信息（20 章前埋的伏笔、久别角色的当前状态、某个时间锚点），按以下顺序查找，**每一步的读取量都有上限**。不允许因为"查着方便"退化成读历史记录文件全文。

| 级别 | 手段 | 成本 |
|------|------|------|
| 1 | 续写状态卡已有 → 直接用 | 0 |
| 2 | 伏笔 ID 查 `grep -n "F007" 追踪/伏笔.md`；角色查 `追踪/角色状态/{名}.md`；读者认知查 `时间线/读者已知.md`，作者真相查 `时间线/作者真相.md` | 一个当前行或一个有界小文件 |
| 3 | 需要变化原因/历史时，调用 story-explorer 的 `foreshadow_status / character_status / timeline`；各 adapter 按自身 agent 调用方式，agent 不可用就直接 Grep/Read | 子代理/主会话只返回相关条目 |
| 4 | explorer 不可用 → `grep -R -n --include='第*.md' "F007" 追踪/逐章记录/ 2>/dev/null \| tail -5`，只取最近 5 条匹配增量 | 只读取匹配行 |
| 5 | 仍不够 → `Read` 对应增量或埋设章正文 | 1 个紧凑增量或单章正文 |
| 6 | 全量读取所有逐章增量/正文 | **日更禁止**。只在 `/story-review` 或用户明确要求全面审计时 |

**查询次数限制**：单章执行步骤 3 和步骤 4 合计超过 3 次，说明细纲没写清本章要消费哪些旧信息。这时一次性让 story-explorer 查询多项，并在批末口头提示细纲需补清回收项，不另写过程日志。

查询结果只有在本章结束后仍影响后续时才进入追踪事务；当前伏笔由 `foreshadow_changes` 更新，核心角色由快照更新，事实/认知由 `timeline_events` 更新。不要直接改续写状态卡某一行。

---

## Step 3：质量检查

每章的质量检查已在 Step 2 随 [workflow-chapter.md](workflow-chapter.md)「质量检查」节完成。批末只做下列**跨章**核对，不重复逐章项：

1. **标题去重检查**：汇总本轮新写章节与既有标题；发现同名或明显重复时，回到对应细纲和正文文件统一重命名
2. **契约与细纲双向核对**：先按 `reader-contract-and-progression.md` 检查读者契约、因果权 + 结算权、关键节点四问、期待所有权、期待债偿还、终局储备（透支两问）；章级推进按权威文件七类状态分档（快节奏保留可见事件/爽点下限），相对本书题材与对标判断；高潮后允许短暂低压和小而可见的收益/奖励。新地图/机构/能力/敌人/谜团须检查换书债；履约爽文/能力幻想另查主角是否反复以可避免的无能制造灾难再由他人收拾。再核对正文是否消费了细纲的内容概括五段式、情节安排多线、人物关系变化/出场顺序、行动成本（可无）/收益归属；并加三条写作要求兑现核对（不达标→修复）：① 爽点出手前是否有可指认的危机/期待铺垫段落？指不出=空洞 → 回 Step 2 补铺垫情节点（plot-emotion-system 倒推法）；② 装逼/打脸/揭露章是否写出在场配角差异化反应（集体震惊/各异），还是只写主角动作？没有 → 补在场配角反应（plot-core-methods）；③ 详略是否按目的词（爽点/卖点点展开、过渡点带过、信息密度交替），还是均匀注水？均匀 → 删过渡、扩爽点点。
3. **伏笔盘点（仅本轮增量）**：确认本批新增/推进/回收的每个 ID 在 `追踪/伏笔.md` 恰好有一行当前状态，并能在对应 `逐章记录/第NNN章.md` 找到本次变化；不得追加第二行历史，也不得在日更流程扫描全部正文做全量伏笔审计

批末再对本批全部落盘正文整体跑一遍 workflow-chapter.md「质量检查」的确定性收尾三脚本（`check-ai-patterns.js` → `normalize-punctuation.js` → `check-degeneration.js`），确认逐章清零后没有回潮。

> 若本步修文改变了会影响后续的事实、角色状态、伏笔、时间线或下一章承诺，必须在进入 Step 4 前为受影响章节提交 `mode=revision` 事务并通过 `check`；其中 `delta` 要重算修订后该章仍成立的完整当前记录，不能只传本次改动；纯措辞调整不重复提交。

---

## Step 4：批末收尾

**本步不再写任何追踪内容**——每章 Step 2 已完成事务。只做两项验证：

1. 对项目运行 `tracking_commit.py check`；验证 state schema、逐章记录连续/规范/未超限、续写状态卡固定 7 栏且不超过 12288 字节，以及全部派生视图与 state 一致。
2. 确认本批每章都有对应 `追踪/逐章记录/第NNN章.md`，每个文件 ≤3072 字节。缺失或超限时不手工补文件，回到该章事务修正并重跑 `commit`。
3. **「本章没写成的」汇集**：把本批各章申报表末行按**挡住它的原因**分流处置——「细纲没有这个点」进下一批补纲供给自查（workflow-setup「按剧情批出细纲」步骤 3）作扩产候选；「分辨率是疏／镜头准入没给位」进下一批同类拍的分辨率与准入参考；「拿不准会不会跟别处撞」当章就查设定，有既定值的补进下一章 prompt、查无既定值的即写手可自定，不再往下传；「属三档不能写」并入三档处置。连同本批细纲「本章新增物处置」里状态仍为 `待裁定` 的行，一并随批末汇报给出；全部为 `0` 则记「无」。

然后向用户口头汇报本批完成情况（章数、字数、漂移、供给反馈、下一批建议），不另存为文件。

---

> **漂移处理**：aligned = 按计划推进；adaptive = 细节适配但不改契约；structural 漂移 / 结构性漂移 = 正文已经改变卷契约、单元承诺、推进线或兑现归属，必须修正文或重规划未来章节细纲，不能只在增量里备注。下一章必须修的漂移进入 `next_chapter_commitments`，跨章风险进入 `continuity_risks`；两者都受续写状态卡上限约束，完整语义以紧凑增量和大纲为准。

## 细纲缺失补建流程

当检测到细纲不存在时，不能跳过。按以下步骤补建：

1. 按 SKILL.md「卷纲不整读」跑 `outline_view.py --unit {单元ID} --stage write` 取本章所属剧情单元卡与卷级常任（**不整读卷纲**）；剧情单元卡含「对标剧情参照」时加读其指向的剧情单元文件（1 个），以其「结构分布」对应位置作本章功能参照；若本章起整个剧情单元均无细纲，按 outline-structure-theory.md「按剧情批出细纲」整批补建而非单章补。卷纲缺必需字段时先补齐，不绕过当前模板继续
2. 加载本章涉及的 `设定/角色/{角色名}.md`（角色状态）
3. 读取最新一章正文（情节衔接）
4. 按 SKILL.md Phase 3 的新版细纲模板补建本章细纲，补齐阶段位置、本章结构公式、本章禁止提前释放、内容概括、情节安排、人物关系/出场顺序、情节细化、结尾设定；无法从卷纲/正文/设定确认的字段写 `[待补充]`，不杜撰
5. 补建完成后继续 Step 2 写作

---

## 常见问题

| 问题 | 处理 |
|------|------|
| 细纲不存在 | 执行上方"细纲缺失补建流程" |
| 细纲缺当前蓝图字段 | 先按当前模板补齐，未知项写 `[待补充]`；未补齐前不写正文 |
| 追踪文件为空 | 正常继续，写作中逐步填充 |
| 用户要求改大纲 | 提醒"改大纲会影响后续细纲"，确认后修改，标记受影响的细纲 |
| 写到卷末 | 提示用户"当前卷已完成，是否开新卷？" |
| 用户中断批量写作 | 保存当前章节，已更新追踪文件，下次从断点继续 |
