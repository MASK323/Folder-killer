# 网文写作工具箱 · 合并版

**版本**: 2.0.0
**包含**: oh-story-claudecode 全套写作技能 + 番茄小说上传技能 + 自定义审核技能

---

## 📦 包含的 Skills（共16个）

### 核心写作

| Skill | 功能 | 触发关键词 |
|-------|------|-----------|
| `story` | 主路由入口 | `/story`、「我想写小说」 |
| `story-setup` | 环境部署 | `/story-setup`、「准备写书」 |
| `story-long-write` | 长篇写作 | 开书、写大纲、长篇、连载、日更 |
| `story-short-write` | 短篇写作 | 短篇、盐言、一万字 |
| `story-long-analyze` | 长篇拆文 | 拆文、黄金三章 |
| `story-short-analyze` | 短篇拆文 | 拆短篇、分析故事 |
| `story-long-scan` | 长篇扫榜 | 起点/番茄/晋江排行、选题 |
| `story-short-scan` | 短篇扫榜 | 知乎盐言排行 |

### 质量工具

| Skill | 功能 | 触发关键词 |
|-------|------|-----------|
| `story-deslop` | 去 AI 味 | 去 AI 味、太 AI、去味 |
| `story-review` | 多视角审稿 | 审查、审稿、一致性检查 |
| `story-import` | 导入已有小说 | 导入、反向解析 |
| `story-cover` | 封面生成 | 封面、封面图 |
| `browser-cdp` | 浏览器操控 | 浏览器、抓取、登录态 |

### 审核与发布

| Skill | 功能 | 触发关键词 |
|-------|------|-----------|
| `novel-punctuation` | 标点符号规范（GB/T 15834） | 标点、弯引号、省略号 |
| `novel-content-safety` | 内容安全规范 | 内容安全、审核、敏感词 |
| `fanqie-novel-upload` | 番茄批量上传 + 判重优化 | 番茄小说、章节重复、被拒收 |

---

## 🚀 推荐工作流

### 新书创作
```
/story-setup              # 1. 初始化环境
/story-long-scan          # 2. 扫榜选题（可选）
/story-long-write         # 3. 写大纲与正文
/story-deslop             # 4. 去 AI 味
/novel-punctuation        # 5. 检查标点
/novel-content-safety     # 6. 内容安全检查
/story-review             # 7. 审稿
/fanqie-novel-upload      # 8. 清理重复并上传番茄
```

### 日更
```
/story-long-write 日更
/story-deslop
/novel-punctuation
/fanqie-novel-upload
```

### 已有作品导入
```
/story-setup
/story-import
/story-long-write 续写
```

---

## 🔍 番茄判重规则速查

**实测规则**（来自 `fanqie-novel-upload`）：

| 情况 | 是否拒收 |
|------|----------|
| 任意一行（≥2字）重复 ≥3 次 | ❌ 拒收 |
| ≥15 字的长行重复 ≥2 次 | ❌ 拒收 |
| 短行重复 ≤2 次 | ✅ 放行 |
| 跨章节重复 | ✅ 放行 |

**清理命令**：
```bash
# 先体检
python scripts/check_repeats.py "章节目录" --min-chars 1000

# 预览要改什么
python scripts/dedupe_novel_files.py "章节目录" --dry-run

# 正式清理（自动备份到 .dup_backup/）
python scripts/dedupe_novel_files.py "章节目录"

# 想保留更多原文时（改写优先）
python scripts/dedupe_novel_files.py "章节目录" --mode rewrite
```

**处理顺序**：相邻复读去掉 → 长行留首次/短行留首末 → 中段留少量改写回响 → 其余去掉；不足1000字自动补回。

---

## 📂 目录结构

```
合并skill包/
├── README.md                     # 本文件
├── story/                        # 主路由
│   ├── SKILL.md
│   ├── references/
│   └── scripts/
├── story-setup/                  # 环境部署
├── story-long-write/             # 长篇写作
├── story-long-analyze/           # 长篇拆文
├── story-long-scan/              # 长篇扫榜
├── story-short-write/            # 短篇写作
├── story-short-analyze/          # 短篇拆文
├── story-short-scan/             # 短篇扫榜
├── story-deslop/                 # 去 AI 味
├── story-import/                 # 导入小说
├── story-review/                 # 审稿
├── story-cover/                  # 封面生成
├── browser-cdp/                  # 浏览器操控
├── novel-punctuation/            # 标点符号规范
├── novel-content-safety/         # 内容安全检查
└── fanqie-novel-upload/          # 番茄上传与判重
    ├── SKILL.md
    ├── references/
    │   ├── platform-rules.md     # 番茄站点实测规则
    │   └── dedupe-algorithm.md   # 去重算法说明
    └── scripts/
        ├── rewrite.py            # 通用改写器
        ├── dedupe_novel_files.py # 批量清理 CLI
        └── check_repeats.py      # 自检脚本
```

---

## 🔧 安装

将各 skill 文件夹放入以下任一目录即可被自动发现：

- `~/.zcode/skills/`（Windows: `C:\Users\<用户名>\.zcode\skills\`）
- `~/.agents/skills/`
- `<项目>/.zcode/skills/`（仅该项目可用）

放好后新开一轮对话，提到相关关键词即自动触发。

---

## ⚠️ 注意事项

1. 首次使用请先运行 `/story-setup` 初始化环境
2. 番茄上传前务必先用 `check_repeats.py` 自检，确认违规残留为 0
3. 清理脚本会自动备份原文件到 `.dup_backup/`，可放心执行
4. 去 AI 味和审稿建议在完成初稿后进行
5. 上传被拒时先清理源文件，清草稿箱无用

---

**来源**: [oh-story-claudecode](https://github.com/zenstory-ai/oh-story-claudecode) + 番茄上传技能 + 自定义审核技能
